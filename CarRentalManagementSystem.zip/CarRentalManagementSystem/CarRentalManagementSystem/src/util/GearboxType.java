package util;

public enum GearboxType {
    AUTOMATIC, MANUAL
}
