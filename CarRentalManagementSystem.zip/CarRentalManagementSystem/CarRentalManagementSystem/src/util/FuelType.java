package util;

public enum FuelType {
    PETROL,
    DIESEL,
    ELECTRIC,
    HYBRID
}
