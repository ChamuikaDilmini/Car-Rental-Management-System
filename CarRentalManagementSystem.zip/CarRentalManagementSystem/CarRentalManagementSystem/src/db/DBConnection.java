package db;

import java.sql.*;

public class DBConnection {

    // Hold actual database connection
    private Connection connection;

    // Singleton instance of DBConnection
    private static DBConnection instance;

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/car_rental_db";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Private constructor to initialize the connection
    private DBConnection() throws SQLException {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Returns the singleton instance of DBConnection
    public static DBConnection getInstance() throws SQLException {
        // If instance is null, create a new one; otherwise, return existing
        return instance == null ? new DBConnection() : instance;
    }

    // Returns the actual Connection object
    public Connection getConnection() {
        return connection;
    }
}
