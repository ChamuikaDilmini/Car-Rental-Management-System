package dao;

import db.DBConnection;
import model.CityAddress;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CityAddressDAO {

    public Map<String, Integer> getAddressMapByCityId(int cityId) {
        Map<String, Integer> addressMap = new HashMap<>();
        String query = "SELECT id, address FROM city_addresses WHERE city_id = ?";

        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, cityId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    addressMap.put(rs.getString("address"), rs.getInt("id"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return addressMap;
    }

    // Load all addresses with city names
    public List<Map<String, Object>> getAllAddressesWithCity() throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT ca.id, ca.address, l.city FROM city_addresses ca JOIN locations l ON ca.city_id = l.id";

        try (Connection con = DBConnection.getInstance().getConnection(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("address", rs.getString("address"));
                row.put("city", rs.getString("city"));
                list.add(row);
            }
        }
        return list;
    }

    // Add address (city must exist or be created)
    public void addAddress(String cityName, String address) throws SQLException {
        int cityId = new LocationDAO().getOrCreateCityId(cityName);
        String sql = "INSERT INTO city_addresses (city_id, address) VALUES (?, ?)";

        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, cityId);
            ps.setString(2, address);
            ps.executeUpdate();
        }
    }

    // Update address
    public void updateAddress(int addressId, String cityName, String address) throws SQLException {
        int cityId = new LocationDAO().getOrCreateCityId(cityName);
        String sql = "UPDATE city_addresses SET city_id = ?, address = ? WHERE id = ?";

        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, cityId);
            ps.setString(2, address);
            ps.setInt(3, addressId);
            ps.executeUpdate();
        }
    }

    // Delete address
    public void deleteAddress(int addressId) throws SQLException {
        String sql = "DELETE FROM city_addresses WHERE id = ?";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, addressId);
            ps.executeUpdate();
        }
    }

    public Map<String, Object> getAddressById(int id) throws SQLException {
        Map<String, Object> map = null;
        String sql = "SELECT ca.id, ca.address, l.city FROM city_addresses ca JOIN locations l ON ca.city_id = l.id WHERE ca.id = ?";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    map = new HashMap<>();
                    map.put("id", rs.getInt("id"));
                    map.put("city", rs.getString("city"));
                    map.put("address", rs.getString("address"));
                }
            }
        }
        return map;
    }

    public List<String> getAddressesByCityId(int cityId) {
        List<String> addresses = new ArrayList<>();

        String query = "SELECT address FROM city_addresses WHERE city_id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, cityId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                addresses.add(rs.getString("address"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return addresses;
    }

    public CityAddress getAddressByID(int addressId) {
        CityAddress cityAddress = null;

        String query = "SELECT id, city_id, address FROM city_addresses WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, addressId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                cityAddress = new CityAddress();
                cityAddress.setId(rs.getInt("id"));
                cityAddress.setLocationId(rs.getInt("city_id"));
                cityAddress.setAddress(rs.getString("address"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return cityAddress;
    }
}
