package dao;

import db.DBConnection;
import java.sql.*;
import java.util.*;
import model.CarImage;

public class CarImageDAO {

    // Get All Images
    public List<CarImage> getAllImages() {
        List<CarImage> images = new ArrayList<>();
        String sql = "SELECT * FROM car_images";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                CarImage image = new CarImage();
                image.setId(rs.getInt("id"));
                image.setCarId(rs.getInt("car_id"));
                image.setImagePath(rs.getString("image_path"));
                images.add(image);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return images;
    }

    // Get Image by ID
    public CarImage getImageById(int id) {
        String sql = "SELECT * FROM car_images WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                CarImage image = new CarImage();
                image.setId(rs.getInt("id"));
                image.setCarId(rs.getInt("car_id"));
                image.setImagePath(rs.getString("image_path"));
                return image;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // Get Images by Car ID
    public List<CarImage> getImagesByCarId(int carId) {
        List<CarImage> images = new ArrayList<>();
        String sql = "SELECT * FROM car_images WHERE car_id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, carId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                CarImage image = new CarImage();
                image.setId(rs.getInt("id"));
                image.setCarId(rs.getInt("car_id"));
                image.setImagePath(rs.getString("image_path"));
                images.add(image);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return images;
    }

    // Add Image
    public boolean addImage(CarImage image) {
        String sql = "INSERT INTO car_images (car_id, image_path) VALUES (?, ?)";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, image.getCarId());
            stmt.setString(2, image.getImagePath());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Update Image
    public boolean updateImage(CarImage image) {
        String sql = "UPDATE car_images SET car_id = ?, image_path = ? WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, image.getCarId());
            stmt.setString(2, image.getImagePath());
            stmt.setInt(3, image.getId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Delete Image by ID
    public boolean deleteImageById(int id) {
        String sql = "DELETE FROM car_images WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Delete All Images by Car ID
    public boolean deleteImagesByCarId(int carId) {
        String sql = "DELETE FROM car_images WHERE car_id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, carId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static List<String> getImagesListByCarId(int carId) {
        List<String> imagePaths = new ArrayList<>();
        String sql = "SELECT image_path FROM car_images WHERE car_id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, carId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                imagePaths.add(rs.getString("image_path"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return imagePaths;
    }
}
