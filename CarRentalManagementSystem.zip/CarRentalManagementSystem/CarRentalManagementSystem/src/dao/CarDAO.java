package dao;

import db.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Car;
import util.FuelType;
import util.GearboxType;

public class CarDAO {

    public int generateNextCarId() {
        String sql = "SELECT MAX(id) AS max_id FROM cars";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("max_id") + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public boolean insertCar(Car car) {
        String sql = "INSERT INTO cars (id, brand_id, model, fuel, color, class, passengers, gearbox, price_per_day) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, car.getId());
            stmt.setInt(2, car.getBrandId());
            stmt.setString(3, car.getModel());
            stmt.setString(4, car.getFuel().toString());
            stmt.setString(5, car.getColor());
            stmt.setString(6, car.getCarClass());
            stmt.setInt(7, car.getPassengers());
            stmt.setString(8, car.getGearbox().toString());
            stmt.setInt(9, car.getPricePerDay());

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                insertCarFeatures(car.getId(), car.getFeatureIds(), conn);
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private void insertCarFeatures(int carId, List<Integer> featureIds, Connection conn) throws SQLException {
        if (featureIds == null || featureIds.isEmpty()) {
            return;
        }

        String sql = "INSERT INTO car_features (car_id, feature_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            for (int featureId : featureIds) {
                stmt.setInt(1, carId);
                stmt.setInt(2, featureId);
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }

    public int getFeatureIdByName(String name) {
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement("SELECT id FROM features WHERE LOWER(name) = LOWER(?)")) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public boolean editCar(Car car) {
        String updateCarSql = "UPDATE cars SET brand_id = ?, model = ?, fuel = ?, color = ?, class = ?, "
                + "passengers = ?, gearbox = ?, price_per_day = ? WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false); // Begin transaction

            // Update the car
            try (PreparedStatement stmt = conn.prepareStatement(updateCarSql)) {
                stmt.setInt(1, car.getBrandId());
                stmt.setString(2, car.getModel());
                stmt.setString(3, car.getFuel().toString());
                stmt.setString(4, car.getColor());
                stmt.setString(5, car.getCarClass());
                stmt.setInt(6, car.getPassengers());
                stmt.setString(7, car.getGearbox().toString());
                stmt.setInt(8, car.getPricePerDay());
                stmt.setInt(9, car.getId());

                int updated = stmt.executeUpdate();
                if (updated == 0) {
                    conn.rollback();
                    return false;
                }
            }

            // Delete old car features
            try (PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM car_features WHERE car_id = ?")) {
                deleteStmt.setInt(1, car.getId());
                deleteStmt.executeUpdate();
            }

            //  Insert updated features
            insertCarFeatures(car.getId(), car.getFeatureIds(), conn);

            conn.commit(); // Commit transaction
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<Car> getAllCars() {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Car car = new Car();
                car.setId(rs.getInt("id"));
                car.setBrandId(rs.getInt("brand_id"));
                car.setModel(rs.getString("model"));
                car.setFuel(FuelType.valueOf(rs.getString("fuel").toUpperCase()));

                car.setColor(rs.getString("color"));
                car.setCarClass(rs.getString("class"));
                car.setPassengers(rs.getInt("passengers"));
                car.setGearbox(GearboxType.valueOf(rs.getString("gearbox").toUpperCase()));
                car.setPricePerDay(rs.getInt("price_per_day"));

                List<Integer> featureIds = getFeatureIdsByCarId(car.getId(), conn);
                car.setFeatureIds(featureIds);

                cars.add(car);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cars;
    }

    private List<Integer> getFeatureIdsByCarId(int carId, Connection conn) {
        List<Integer> featureIds = new ArrayList<>();
        String sql = "SELECT feature_id FROM car_features WHERE car_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, carId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                featureIds.add(rs.getInt("feature_id"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return featureIds;
    }

    public Car searchCar(int carId) throws SQLException {
        String sql = "SELECT * FROM cars WHERE id = ?";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, carId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Car car = new Car();
                car.setId(rs.getInt("id"));
                car.setBrandId(rs.getInt("brand_id"));
                car.setModel(rs.getString("model"));
                car.setFuel(FuelType.valueOf(rs.getString("fuel").toUpperCase()));
                car.setColor(rs.getString("color"));
                car.setCarClass(rs.getString("class"));
                car.setPassengers(rs.getInt("passengers"));
                car.setGearbox(GearboxType.valueOf(rs.getString("gearbox").toUpperCase()));
                car.setPricePerDay(rs.getInt("price_per_day"));

                // Fetch feature IDs
                List<Integer> featureIds = getCarFeatureIds(carId);
                car.setFeatureIds(featureIds);

                return car;
            }
        }
        return null; // Car not found
    }

    private List<Integer> getCarFeatureIds(int carId) throws SQLException {
        List<Integer> featureIds = new ArrayList<>();
        String sql = "SELECT feature_id FROM car_features WHERE car_id = ?";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, carId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                featureIds.add(rs.getInt("feature_id"));
            }
        }
        return featureIds;
    }

    public List<Car> getCarsByBrandId(int brandId) {
        List<Car> carList = new ArrayList<>();
        String query = "SELECT * FROM cars WHERE brand_id = ?";

        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, brandId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Car car = new Car();
                    car.setId(rs.getInt("id"));
                    car.setBrandId(rs.getInt("brand_id"));
                    car.setModel(rs.getString("model"));
                    car.setFuel(FuelType.valueOf(rs.getString("fuel").toUpperCase()));
                    car.setColor(rs.getString("color"));
                    car.setCarClass(rs.getString("class"));
                    car.setPassengers(rs.getInt("passengers"));
                    car.setGearbox(GearboxType.valueOf(rs.getString("gearbox").toUpperCase()));
                    car.setPricePerDay(rs.getInt("price_per_day"));

                    carList.add(car);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return carList;
    }

    public boolean deleteCar(int carId) {
        String deleteCarSql = "DELETE FROM cars WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection()) {
            try (PreparedStatement deleteFeaturesStmt = conn.prepareStatement("DELETE FROM car_features WHERE car_id = ?")) {
                deleteFeaturesStmt.setInt(1, carId);
                deleteFeaturesStmt.executeUpdate();
            }
            try (PreparedStatement deleteCarStmt = conn.prepareStatement(deleteCarSql)) {
                deleteCarStmt.setInt(1, carId);
                int rows = deleteCarStmt.executeUpdate();
                return rows > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public int getTotalCars() throws SQLException {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM cars";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                count = rs.getInt(1);
            }
        }
        return count;
    }
}
