package dao;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocationDAO {

    // Generate next Location ID
    public int generateNextLocationId() {
        String sql = "SELECT MAX(id) AS max_id FROM locations";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("max_id") + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public Map<String, Integer> getCityMap() {
        Map<String, Integer> cityMap = new HashMap<>();
        String query = "SELECT id, city FROM locations";

        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                cityMap.put(rs.getString("city"), rs.getInt("id"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cityMap;
    }

    public int getOrCreateCityId(String cityName) throws SQLException {
        String selectSQL = "SELECT id FROM locations WHERE city = ?";
        String insertSQL = "INSERT INTO locations (id, city) VALUES (?, ?)";

        try (Connection con = DBConnection.getInstance().getConnection()) {
            // Check if city exists
            try (PreparedStatement ps = con.prepareStatement(selectSQL)) {
                ps.setString(1, cityName);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }

            // Generate next id manually
            int nextId = generateNextLocationId();

            // Insert new city with explicit id
            try (PreparedStatement ps = con.prepareStatement(insertSQL)) {
                ps.setInt(1, nextId);
                ps.setString(2, cityName);
                ps.executeUpdate();
                return nextId;
            }
        }
    }

    public String getCityNameById(int cityId) throws SQLException {
        String query = "SELECT city FROM locations WHERE id = ?";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, cityId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("city");
            }
        }
        return null;
    }

    public List<String> getAllCities() {
        List<String> cities = new ArrayList<>();
        String sql = "SELECT DISTINCT city FROM locations ORDER BY city";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                cities.add(rs.getString("city"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cities;
    }
}
