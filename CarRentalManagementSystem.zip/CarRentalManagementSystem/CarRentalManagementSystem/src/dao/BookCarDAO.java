package dao;

import db.DBConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.BookCar;

public class BookCarDAO {

    public boolean saveBooking(BookCar booking) throws SQLException {
        String sql = "INSERT INTO bookings (car_id, customer_id, pickup_location_id, pickup_address_id, "
                + "dropoff_location_id, dropoff_address_id, pickup_datetime, return_datetime, total_price) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection connection = DBConnection.getInstance().getConnection();
        PreparedStatement prepareStatement = connection.prepareStatement(sql);

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, booking.getCarId());
            ps.setInt(2, booking.getCustomerId());
            ps.setInt(3, booking.getPickupCityId());
            ps.setInt(4, booking.getPickupAddressId());
            ps.setInt(5, booking.getDropoffCityId());
            ps.setInt(6, booking.getDropoffAddressId());
            ps.setTimestamp(7, Timestamp.valueOf(booking.getPickupDateTime()));
            ps.setTimestamp(8, Timestamp.valueOf(booking.getReturnDateTime()));
            ps.setInt(9, booking.getTotalPrice());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Object[]> getAllBookingTableRows() {
        List<Object[]> rows = new ArrayList<>();

        String sql = """
        SELECT 
            b.id, b.car_id, b.customer_id,
            pickup_city.city AS pickup_city,
            pickup_address.address AS pickup_address,
            b.pickup_datetime,
            dropoff_city.city AS dropoff_city,
            dropoff_address.address AS dropoff_address,
            b.return_datetime,
            b.total_price
        FROM bookings b
        JOIN locations pickup_city ON b.pickup_location_id = pickup_city.id
        JOIN city_addresses pickup_address ON b.pickup_address_id = pickup_address.id
        JOIN locations dropoff_city ON b.dropoff_location_id = dropoff_city.id
        JOIN city_addresses dropoff_address ON b.dropoff_address_id = dropoff_address.id
        ORDER BY b.id DESC
    """;

        try (
                Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                LocalDateTime pickupDT = rs.getTimestamp("pickup_datetime").toLocalDateTime();
                LocalDateTime dropoffDT = rs.getTimestamp("return_datetime").toLocalDateTime();

                Object[] row = {
                    rs.getInt("id"),
                    rs.getInt("car_id"),
                    rs.getInt("customer_id"),
                    rs.getString("pickup_city"),
                    rs.getString("pickup_address"),
                    pickupDT.toLocalDate(),
                    pickupDT.toLocalTime(),
                    rs.getString("dropoff_city"),
                    rs.getString("dropoff_address"),
                    dropoffDT.toLocalDate(),
                    dropoffDT.toLocalTime(),
                    rs.getInt("total_price")
                };

                rows.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rows;
    }

    public BookCar getBookingById(int id) {
        String sql = "SELECT * FROM bookings WHERE id = ?";
        try (
                Connection connection = DBConnection.getInstance().getConnection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                BookCar booking = new BookCar();
                booking.setId(rs.getInt("id"));
                booking.setCarId(rs.getInt("car_id"));
                booking.setCustomerId(rs.getInt("customer_id"));
                booking.setPickupCityId(rs.getInt("pickup_location_id"));
                booking.setPickupAddressId(rs.getInt("pickup_address_id"));
                booking.setDropoffCityId(rs.getInt("dropoff_location_id"));
                booking.setDropoffAddressId(rs.getInt("dropoff_address_id"));
                booking.setPickupDateTime(rs.getTimestamp("pickup_datetime").toLocalDateTime());
                booking.setReturnDateTime(rs.getTimestamp("return_datetime").toLocalDateTime());
                booking.setTotalPrice(rs.getInt("total_price"));

                return booking;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public BookCar editBookingById(int bookingId) {
        BookCar booking = null;

        String query = "SELECT "
                + "b.id, b.car_id, c.brand_id, c.model, c.price_per_day, "
                + "cu.id as customer_id, cu.name as customer_name, "
                + "pl.id as pickup_city_id, pl.city AS pickup_city, "
                + "pa.id as pickup_address_id, pa.address AS pickup_address, "
                + "dl.id as dropoff_city_id, dl.city AS dropoff_city, "
                + "da.id as dropoff_address_id, da.address AS dropoff_address, "
                + "b.pickup_datetime, b.return_datetime, b.total_price "
                + "FROM bookings b "
                + "JOIN cars c ON b.car_id = c.id "
                + "JOIN brands br ON c.brand_id = br.id "
                + "JOIN customers cu ON b.customer_id = cu.id "
                + "JOIN locations pl ON b.pickup_location_id = pl.id "
                + "JOIN city_addresses pa ON b.pickup_address_id = pa.id "
                + "JOIN locations dl ON b.dropoff_location_id = dl.id "
                + "JOIN city_addresses da ON b.dropoff_address_id = da.id "
                + "WHERE b.id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                booking = new BookCar();

                booking.setId(rs.getInt("id"));
                booking.setCarId(rs.getInt("car_id"));
                booking.setCustomerId(rs.getInt("customer_id"));
                booking.setPickupCityId(rs.getInt("pickup_city_id"));
                booking.setPickupAddressId(rs.getInt("pickup_address_id"));
                booking.setDropoffCityId(rs.getInt("dropoff_city_id"));
                booking.setDropoffAddressId(rs.getInt("dropoff_address_id"));
                booking.setPickupDateTime(rs.getTimestamp("pickup_datetime").toLocalDateTime());
                booking.setReturnDateTime(rs.getTimestamp("return_datetime").toLocalDateTime());
                booking.setTotalPrice(rs.getInt("total_price"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return booking;
    }

    public boolean deleteBooking(int bookingId) throws SQLException {
        String sql = "DELETE FROM bookings WHERE id=?";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateBooking(BookCar booking) throws SQLException {
        String sql = "UPDATE bookings SET car_id = ?, customer_id = ?, pickup_location_id = ?, pickup_address_id = ?, "
                + "dropoff_location_id = ?, dropoff_address_id = ?, pickup_datetime = ?, return_datetime = ?, total_price = ? "
                + "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection(); PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, booking.getCarId());
            ps.setInt(2, booking.getCustomerId());
            ps.setInt(3, booking.getPickupCityId());
            ps.setInt(4, booking.getPickupAddressId());
            ps.setInt(5, booking.getDropoffCityId());
            ps.setInt(6, booking.getDropoffAddressId());
            ps.setTimestamp(7, Timestamp.valueOf(booking.getPickupDateTime()));
            ps.setTimestamp(8, Timestamp.valueOf(booking.getReturnDateTime()));
            ps.setInt(9, booking.getTotalPrice());
            ps.setInt(10, booking.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public int getTotalBookings() throws SQLException {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM bookings";
        try (Connection con = DBConnection.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                count = rs.getInt(1);
            }
        }
        return count;
    }
}
