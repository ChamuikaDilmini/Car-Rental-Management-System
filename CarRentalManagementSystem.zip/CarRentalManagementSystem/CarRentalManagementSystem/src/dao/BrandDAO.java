package dao;

import db.DBConnection;
import java.sql.*;
import java.util.*;
import model.Brand;

public class BrandDAO {

    // Generate next brand ID
    public int generateNextBrandId() {
        String sql = "SELECT MAX(id) AS max_id FROM brands";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("max_id") + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    // Add brand
    public boolean addBrand(Brand brand) {
        int nextId = generateNextBrandId();
        String sql = "INSERT INTO brands (id, brand_name, logo) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, nextId);
            stmt.setString(2, brand.getBrandName());
            stmt.setString(3, brand.getLogo());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update brand
    public boolean updateBrand(Brand brand) {
        String sql = "UPDATE brands SET brand_name = ?, logo = ? WHERE id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, brand.getBrandName());
            stmt.setString(2, brand.getLogo());
            stmt.setInt(3, brand.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete brand
    public boolean deleteBrand(int id) {
        String sql = "DELETE FROM brands WHERE id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get all brands
    public List<Brand> getAllBrands() {
        List<Brand> brandList = new ArrayList<>();
        String sql = "SELECT * FROM brands";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Brand brand = new Brand();
                brand.setId(rs.getInt("id"));
                brand.setBrandName(rs.getString("brand_name"));
                brand.setLogo(rs.getString("logo"));
                brandList.add(brand);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return brandList;
    }

    // Get brand by ID
    public Brand getBrandById(int id) {
        String sql = "SELECT * FROM brands WHERE id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Brand brand = new Brand();
                brand.setId(rs.getInt("id"));
                brand.setBrandName(rs.getString("brand_name"));
                brand.setLogo(rs.getString("logo"));
                return brand;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Map<String, Integer> getAllBrandNameIdMap() {
        Map<String, Integer> brandMap = new HashMap<>();
        String sql = "SELECT id, brand_name FROM brands";

        try (Connection conn = DBConnection.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("brand_name");
                brandMap.put(name, id);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return brandMap;
    }
}
