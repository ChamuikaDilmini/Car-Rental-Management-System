package model;

import java.util.List;
import util.FuelType;
import util.GearboxType;

public class Car {

    private int id;
    private int brandId;
    private String model;
    private FuelType fuel;
    private String color;
    private String carClass;
    private int passengers;
    private GearboxType gearbox;
    private int pricePerDay;
    private String image;
    private List<Integer> featureIds;

    // Default constructor 
    public Car() {
    }

    // Parameterized constructor
    public Car(int id, int brandId, String model, FuelType fuel, String color, String carClass, int passengers, GearboxType gearbox, int pricePerDay, String image, List<Integer> featureIds) {
        this.id = id;
        this.brandId = brandId;
        this.model = model;
        this.fuel = fuel;
        this.color = color;
        this.carClass = carClass;
        this.passengers = passengers;
        this.gearbox = gearbox;
        this.pricePerDay = pricePerDay;
        this.image = image;
        this.featureIds = featureIds;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBrandId() {
        return brandId;
    }

    public void setBrandId(int brandId) {
        this.brandId = brandId;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public FuelType getFuel() {
        return fuel;
    }

    public void setFuel(FuelType fuel) {
        this.fuel = fuel;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getCarClass() {
        return carClass;
    }

    public void setCarClass(String carClass) {
        this.carClass = carClass;
    }

    public int getPassengers() {
        return passengers;
    }

    public void setPassengers(int passengers) {
        this.passengers = passengers;
    }

    public GearboxType getGearbox() {
        return gearbox;
    }

    public void setGearbox(GearboxType gearbox) {
        this.gearbox = gearbox;
    }

    public int getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(int pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public List<Integer> getFeatureIds() {
        return featureIds;
    }

    public void setFeatureIds(List<Integer> featureIds) {
        this.featureIds = featureIds;
    }
}
