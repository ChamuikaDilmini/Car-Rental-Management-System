package model;

import java.time.LocalDateTime;

public class BookCar {

    private int id;
    private int carId;
    private int customerId;
    private int pickupCityId;
    private int pickupAddressId;
    private int dropoffCityId;
    private int dropoffAddressId;
    private LocalDateTime pickupDateTime;
    private LocalDateTime returnDateTime;
    private int totalPrice;

    public BookCar() {
    }

    public BookCar(int id, int carId, int customerId, int pickupCityId, int pickupAddressId, int dropoffCityId, int dropoffAddressId, LocalDateTime pickupDateTime, LocalDateTime returnDateTime, int totalPrice) {
        this.id = id;
        this.carId = carId;
        this.customerId = customerId;
        this.pickupCityId = pickupCityId;
        this.pickupAddressId = pickupAddressId;
        this.dropoffCityId = dropoffCityId;
        this.dropoffAddressId = dropoffAddressId;
        this.pickupDateTime = pickupDateTime;
        this.returnDateTime = returnDateTime;
        this.totalPrice = totalPrice;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getPickupCityId() {
        return pickupCityId;
    }

    public void setPickupCityId(int pickupCityId) {
        this.pickupCityId = pickupCityId;
    }

    public int getPickupAddressId() {
        return pickupAddressId;
    }

    public void setPickupAddressId(int pickupAddressId) {
        this.pickupAddressId = pickupAddressId;
    }

    public int getDropoffCityId() {
        return dropoffCityId;
    }

    public void setDropoffCityId(int dropoffCityId) {
        this.dropoffCityId = dropoffCityId;
    }

    public int getDropoffAddressId() {
        return dropoffAddressId;
    }

    public void setDropoffAddressId(int dropoffAddressId) {
        this.dropoffAddressId = dropoffAddressId;
    }

    public LocalDateTime getPickupDateTime() {
        return pickupDateTime;
    }

    public void setPickupDateTime(LocalDateTime pickupDateTime) {
        this.pickupDateTime = pickupDateTime;
    }

    public LocalDateTime getReturnDateTime() {
        return returnDateTime;
    }

    public void setReturnDateTime(LocalDateTime returnDateTime) {
        this.returnDateTime = returnDateTime;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }
}
