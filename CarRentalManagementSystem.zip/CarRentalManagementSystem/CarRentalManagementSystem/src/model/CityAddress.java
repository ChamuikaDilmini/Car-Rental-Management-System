package model;

public class CityAddress {

    private int id;
    private int locationId;
    private String address;

    public CityAddress() {
    }

    public CityAddress(int id, int locationId, String address) {
        this.id = id;
        this.locationId = locationId;
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
