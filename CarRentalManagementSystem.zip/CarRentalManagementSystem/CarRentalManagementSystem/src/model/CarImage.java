package model;

public class CarImage {

    private int id;
    private int carId;
    private String imagePath;

    // Default constructor
    public CarImage() {
    }

    // Parameterized constructor
    public CarImage(int id, int carId, String imagePath) {
        this.id = id;
        this.carId = carId;
        this.imagePath = imagePath;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
