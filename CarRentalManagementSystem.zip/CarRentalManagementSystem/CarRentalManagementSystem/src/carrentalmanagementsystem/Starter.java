package carrentalmanagementsystem;

import view.Login;

public class Starter {
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}