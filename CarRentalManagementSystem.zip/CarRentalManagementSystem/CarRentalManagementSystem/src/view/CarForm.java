package view;

import dao.BrandDAO;
import dao.CarDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import model.Car;
import util.FuelType;
import util.GearboxType;

public class CarForm extends javax.swing.JFrame {

    private Map<String, Integer> brandMap = new HashMap<>();
    private boolean isCarSearched = false;
    Dashboard dashboard;

    private String getBrandNameById(int brandId) {
        for (Map.Entry<String, Integer> entry : brandMap.entrySet()) {
            if (entry.getValue() == brandId) {
                return entry.getKey();
            }
        }
        return null;
    }

    public CarForm(Dashboard dashboard) {
        initComponents();
        setTitle("Car");
        setLocationRelativeTo(null);
        loadFuelTypes();
        loadCarBrands();
        clearForm();
        this.dashboard = dashboard;
        dashboard.refreshDashboardCounts();
    }

    private void loadFuelTypes() {
        cmbFuel.removeAllItems();
        for (FuelType fuel : FuelType.values()) {
            cmbFuel.addItem(fuel.toString());
        }
    }

    private void loadCarBrands() {
        brandMap = new BrandDAO().getAllBrandNameIdMap();
        cmbBrand.removeAllItems();
        for (String brandName : brandMap.keySet()) {
            cmbBrand.addItem(brandName);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_brands_logo = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        CarIdSpinner = new javax.swing.JSpinner();
        jButton_browse = new javax.swing.JButton();
        jButton_Add = new javax.swing.JButton();
        btnEditCar = new javax.swing.JButton();
        jButton_Remove1 = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtModel = new javax.swing.JTextField();
        cmbBrand = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cmbFuel = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        brandIDLbl = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtCarClass = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtPassengers = new javax.swing.JSpinner();
        jLabel11 = new javax.swing.JLabel();
        rdoAutomatic = new javax.swing.JRadioButton();
        rdoManual = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        spinnerPrice = new javax.swing.JSpinner();
        jLabel13 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        chkAirConditioning = new javax.swing.JCheckBox();
        chkAirBags = new javax.swing.JCheckBox();
        chkSunProof = new javax.swing.JCheckBox();
        chkHeatedSeats = new javax.swing.JCheckBox();
        chkNavigation = new javax.swing.JCheckBox();
        chkBluetooth = new javax.swing.JCheckBox();
        chkElectricWindows = new javax.swing.JCheckBox();
        chkGPS = new javax.swing.JCheckBox();
        brandListBtn = new javax.swing.JButton();
        carListBtn = new javax.swing.JButton();
        txtColor = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 5));

        jPanel3.setBackground(new java.awt.Color(87, 96, 111));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Cars");
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel_brands_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/carLogo.png"))); // NOI18N

        jLabel_close.setText(" X");
        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel_brands_logo)
                .addGap(299, 299, 299)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addComponent(jLabel_brands_logo)
                .addContainerGap(11, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setText("ID:");
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        jLabel2.setText("Brand:");
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        CarIdSpinner.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jButton_browse.setBackground(new java.awt.Color(204, 51, 255));
        jButton_browse.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_browse.setForeground(new java.awt.Color(255, 255, 255));
        jButton_browse.setText("Add Car Images");
        jButton_browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_browseActionPerformed(evt);
            }
        });

        jButton_Add.setBackground(new java.awt.Color(29, 209, 161));
        jButton_Add.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Add.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Add.setText("Add");
        jButton_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddActionPerformed(evt);
            }
        });

        btnEditCar.setText("Edit");
        btnEditCar.setBackground(new java.awt.Color(0, 204, 255));
        btnEditCar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEditCar.setForeground(new java.awt.Color(255, 255, 255));
        btnEditCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditCarActionPerformed(evt);
            }
        });

        jButton_Remove1.setBackground(new java.awt.Color(255, 153, 0));
        jButton_Remove1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Remove1.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Remove1.setText("Remove");
        jButton_Remove1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Remove1ActionPerformed(evt);
            }
        });

        btnReset.setBackground(new java.awt.Color(255, 233, 17));
        btnReset.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.setBackground(new java.awt.Color(0, 102, 255));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        jLabel6.setText("Model:");
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        txtModel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtModel.setText(" ");

        cmbBrand.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbBrand.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbBrand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbBrandActionPerformed(evt);
            }
        });

        jLabel8.setText("Fuel:");
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        cmbFuel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbFuel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbFuel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFuelActionPerformed(evt);
            }
        });

        jLabel9.setText("Color:");
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        brandIDLbl.setText("1");
        brandIDLbl.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel7.setText("Class:");
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        txtCarClass.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtCarClass.setText(" ");

        jLabel3.setText("Passengers:");
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        txtPassengers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jLabel11.setText("Gearbox:");
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        rdoAutomatic.setText("Automatic");
        rdoAutomatic.setBackground(new java.awt.Color(255, 255, 255));
        rdoAutomatic.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        rdoManual.setText("Manual");
        rdoManual.setBackground(new java.awt.Color(255, 255, 255));
        rdoManual.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        jLabel12.setText("Price/day:");
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        spinnerPrice.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jLabel13.setText("Features:");
        jLabel13.setFont(new java.awt.Font("Segoe UI Semibold", 0, 26)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 51, 204));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        chkAirConditioning.setText("Air Conditioning");
        chkAirConditioning.setBackground(new java.awt.Color(204, 204, 204));
        chkAirConditioning.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        chkAirBags.setText("Air bags");
        chkAirBags.setBackground(new java.awt.Color(204, 204, 204));
        chkAirBags.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        chkSunProof.setText("Sunroof");
        chkSunProof.setBackground(new java.awt.Color(204, 204, 204));
        chkSunProof.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        chkHeatedSeats.setText("Heated Seats");
        chkHeatedSeats.setBackground(new java.awt.Color(204, 204, 204));
        chkHeatedSeats.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        chkNavigation.setText("Navigation Systems");
        chkNavigation.setBackground(new java.awt.Color(204, 204, 204));
        chkNavigation.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        chkBluetooth.setText("Bluetooth");
        chkBluetooth.setBackground(new java.awt.Color(204, 204, 204));
        chkBluetooth.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        chkBluetooth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkBluetoothActionPerformed(evt);
            }
        });

        chkElectricWindows.setText("Electric Windows");
        chkElectricWindows.setBackground(new java.awt.Color(204, 204, 204));
        chkElectricWindows.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        chkElectricWindows.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkElectricWindowsActionPerformed(evt);
            }
        });

        chkGPS.setText("GPS");
        chkGPS.setBackground(new java.awt.Color(204, 204, 204));
        chkGPS.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chkAirConditioning)
                    .addComponent(chkAirBags))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chkSunProof)
                    .addComponent(chkHeatedSeats))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chkNavigation)
                    .addComponent(chkBluetooth))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chkElectricWindows)
                    .addComponent(chkGPS))
                .addGap(46, 46, 46))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(chkSunProof)
                        .addGap(18, 18, 18)
                        .addComponent(chkHeatedSeats))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(chkNavigation)
                        .addGap(18, 18, 18)
                        .addComponent(chkBluetooth))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(chkAirConditioning))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(chkElectricWindows)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chkAirBags)
                            .addComponent(chkGPS))))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        brandListBtn.setText("Brand List");
        brandListBtn.setBackground(new java.awt.Color(204, 51, 255));
        brandListBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        brandListBtn.setForeground(new java.awt.Color(255, 255, 255));
        brandListBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brandListBtnActionPerformed(evt);
            }
        });

        carListBtn.setText("Car List");
        carListBtn.setBackground(new java.awt.Color(204, 51, 255));
        carListBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        carListBtn.setForeground(new java.awt.Color(255, 255, 255));
        carListBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carListBtnActionPerformed(evt);
            }
        });

        txtColor.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jButton_browse, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(30, 30, 30)
                            .addComponent(brandListBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(29, 29, 29)
                            .addComponent(carListBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jButton_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(36, 36, 36)
                            .addComponent(btnEditCar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(35, 35, 35)
                            .addComponent(jButton_Remove1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(34, 34, 34)
                            .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtModel, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addGap(4, 4, 4)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addGap(18, 18, 18)
                                            .addComponent(cmbBrand, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(jLabel1)
                                            .addGap(18, 18, 18)
                                            .addComponent(CarIdSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(btnSearch)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cmbFuel, 0, 271, Short.MAX_VALUE)
                                    .addComponent(txtColor))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(brandIDLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(rdoAutomatic)
                                .addGap(106, 106, 106))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(spinnerPrice)
                                    .addComponent(rdoManual, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtPassengers)
                                    .addComponent(txtCarClass, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CarIdSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSearch)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cmbBrand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(brandIDLbl))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtModel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cmbFuel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCarClass, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtPassengers, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(rdoAutomatic)
                            .addComponent(rdoManual))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(spinnerPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(27, 27, 27)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_Add)
                    .addComponent(btnEditCar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton_Remove1)
                    .addComponent(btnReset))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_browse)
                    .addComponent(brandListBtn)
                    .addComponent(carListBtn))
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void carListBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carListBtnActionPerformed
        new AllCars().setVisible(true);
    }//GEN-LAST:event_carListBtnActionPerformed

    private void brandListBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brandListBtnActionPerformed
        new AllBrands().setVisible(true);
    }//GEN-LAST:event_brandListBtnActionPerformed

    private void chkElectricWindowsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkElectricWindowsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkElectricWindowsActionPerformed

    private void chkBluetoothActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkBluetoothActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkBluetoothActionPerformed

    private void cmbBrandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbBrandActionPerformed
        String selectedBrandName = (String) cmbBrand.getSelectedItem();
        if (selectedBrandName != null && brandMap.containsKey(selectedBrandName)) {
            int selectedBrandId = brandMap.get(selectedBrandName);
            brandIDLbl.setText(String.valueOf(selectedBrandId));
        }
    }//GEN-LAST:event_cmbBrandActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        clearForm();
    }//GEN-LAST:event_btnResetActionPerformed

    private void jButton_Remove1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Remove1ActionPerformed
        if (!isCarSearched) {
            JOptionPane.showMessageDialog(this, "Please search for the Car ID before attempting to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this car?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        int carId = (Integer) CarIdSpinner.getValue();
        CarDAO carDAO = new CarDAO();
        boolean deleted = carDAO.deleteCar(carId);

        if (deleted) {
            JOptionPane.showMessageDialog(this, "Car deleted successfully.");
            dashboard.refreshDashboardCounts();
            clearForm();
            isCarSearched = false;
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete car. It may not exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton_Remove1ActionPerformed

    private void btnEditCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditCarActionPerformed
        if (!isCarSearched) {
            JOptionPane.showMessageDialog(this, "Please search for the Car ID before editing.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Car car = validateCarForm(); // Get updated values
            if (car == null) {
                return;
            }

            int carId = (Integer) CarIdSpinner.getValue();
            car.setId(carId); // Set existing ID

            List<Integer> featureIds = new ArrayList<>();
            CarDAO dao = new CarDAO();

            if (chkAirConditioning.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Air Conditioning"));
            }
            if (chkSunProof.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Sun Proof"));
            }
            if (chkNavigation.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Navigation Systems"));
            }
            if (chkAirBags.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Air Bags"));
            }
            if (chkBluetooth.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Bluetooth"));
            }
            if (chkHeatedSeats.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Heated Seats"));
            }
            if (chkGPS.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("GPS"));
            }
            if (chkElectricWindows.isSelected()) {
                featureIds.add(dao.getFeatureIdByName("Electric Windows"));
            }

            // Set selected feature IDs into the car object
            car.setFeatureIds(featureIds);

            boolean updated = new CarDAO().editCar(car);

            if (updated) {
                JOptionPane.showMessageDialog(this, "Car details updated successfully.");
                isCarSearched = false;
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update car details.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Exception", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEditCarActionPerformed

    private Car validateCarForm() {
        List<String> errors = new ArrayList<>();
        Car car = new Car();

        boolean anyFieldFilled = false; // To check if at least one field is filled

        // Validate brand
        String selectedBrandName = (String) cmbBrand.getSelectedItem();
        if (selectedBrandName == null || !brandMap.containsKey(selectedBrandName)) {
            errors.add("Please select a valid brand.");
        } else {
            anyFieldFilled = true;
            car.setBrandId(brandMap.get(selectedBrandName));
        }

        // Validate model
        String model = txtModel.getText().trim();
        if (model.isEmpty()) {
            errors.add("Model is required.");
        } else {
            anyFieldFilled = true;
            car.setModel(model);
        }

        // Validate fuel type
        String fuelStr = (String) cmbFuel.getSelectedItem();
        if (fuelStr == null || fuelStr.isEmpty()) {
            errors.add("Fuel type is required.");
        } else {
            anyFieldFilled = true;
            try {
                car.setFuel(FuelType.valueOf(fuelStr));
            } catch (IllegalArgumentException e) {
                errors.add("Invalid fuel type selected.");
            }
        }

        // Validate color
        String color = txtColor.getText().trim();
        if (color.isEmpty()) {
            errors.add("Color is required.");
        } else {
            anyFieldFilled = true;
            car.setColor(color);
        }

        // Validate car class
        String carClass = txtCarClass.getText().trim();
        if (carClass.isEmpty()) {
            errors.add("Car class is required.");
        } else {
            anyFieldFilled = true;
            car.setCarClass(carClass);
        }

        // Validate passengers
        int passengers = (int) txtPassengers.getValue();
        if (passengers <= 0) {
            errors.add("Passengers must be greater than 0.");
        } else {
            anyFieldFilled = true;
            car.setPassengers(passengers);
        }

        // Gearbox
        car.setGearbox(rdoAutomatic.isSelected() ? GearboxType.AUTOMATIC : GearboxType.MANUAL);

        // Validate price
        int price = (int) spinnerPrice.getValue();
        if (price <= 0) {
            errors.add("Price per day must be greater than 0.");
        } else {
            anyFieldFilled = true;
            car.setPricePerDay(price);
        }

        // If nothing at all is filled
        if (!anyFieldFilled) {
            JOptionPane.showMessageDialog(this, "All fields must be filled.", " Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        // Show all validation errors
        if (!errors.isEmpty()) {
            JOptionPane.showMessageDialog(this, String.join("\n", errors), " Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        return car;
    }

    private void jButton_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddActionPerformed
        try {
            Car car = validateCarForm();
            if (car == null) {
                return;
            }

            car.setId(new CarDAO().generateNextCarId());
            String selectedBrandName = (String) cmbBrand.getSelectedItem();

            if (selectedBrandName != null && brandMap.containsKey(selectedBrandName)) {
                int brandId = brandMap.get(selectedBrandName);
                car.setBrandId(brandId);
            } else {
                // handle error or show message
                JOptionPane.showMessageDialog(this, "Please select a valid brand.");
            }

            car.setModel(txtModel.getText());
            car.setFuel(FuelType.valueOf((String) cmbFuel.getSelectedItem()));
            car.setColor(txtColor.getText());
            car.setCarClass(txtCarClass.getText());
            car.setPassengers(Integer.parseInt(txtPassengers.getValue().toString()));
            car.setGearbox(rdoAutomatic.isSelected() ? GearboxType.AUTOMATIC : GearboxType.MANUAL);
            car.setPricePerDay(Integer.parseInt(spinnerPrice.getValue().toString()));

            // Collect selected features
            List<Integer> featureIds = new ArrayList<>();
            if (chkAirConditioning.isSelected()) {
                featureIds.add(new CarDAO().getFeatureIdByName("Air Conditioning"));
            }
            if (chkSunProof.isSelected()) {
                featureIds.add(new CarDAO().getFeatureIdByName("Sun Proof"));
            }
            if (chkNavigation.isSelected()) {
                featureIds.add(new CarDAO().getFeatureIdByName("Navigation Systems"));
            }
            if (chkAirBags.isSelected()) {
                featureIds.add(new CarDAO().getFeatureIdByName("Air Bags"));
            }
            if (chkBluetooth.isSelected()) {
                featureIds.add(new CarDAO().getFeatureIdByName("Bluetooth"));
            }
            if (chkHeatedSeats.isSelected()) {
                featureIds.add(new CarDAO().getFeatureIdByName("Heated Seats"));
            }

            car.setFeatureIds(featureIds);

            CarDAO dao = new CarDAO();
            if (dao.insertCar(car)) {
                JOptionPane.showMessageDialog(this, " The New Car has been added successfully.");
                dashboard.refreshDashboardCounts();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add car.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton_AddActionPerformed

    private void jButton_browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_browseActionPerformed
        new CarImages().setVisible(true);
    }//GEN-LAST:event_jButton_browseActionPerformed

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        int carId = (int) CarIdSpinner.getValue();
        if (carId == 0) {
            JOptionPane.showMessageDialog(this, "Please enter a Car ID to search.");
            return;
        }

        try {
            CarDAO dao = new CarDAO();
            Car car = dao.searchCar(carId);

            if (car != null) {
                cmbBrand.setSelectedItem(getBrandNameById(car.getBrandId()));
                txtModel.setText(car.getModel());
                cmbFuel.setSelectedItem(car.getFuel().toString());
                txtColor.setText(car.getColor());
                txtCarClass.setText(car.getCarClass());
                txtPassengers.setValue(car.getPassengers());
                spinnerPrice.setValue(car.getPricePerDay());

                if (car.getGearbox() == GearboxType.AUTOMATIC) {
                    rdoAutomatic.setSelected(true);
                } else {
                    rdoManual.setSelected(true);
                }

                // Set features
                List<Integer> features = car.getFeatureIds();
                chkAirConditioning.setSelected(features.contains(dao.getFeatureIdByName("Air Conditioning")));
                chkSunProof.setSelected(features.contains(dao.getFeatureIdByName("Sun Proof")));
                chkNavigation.setSelected(features.contains(dao.getFeatureIdByName("GPS")));
                chkAirBags.setSelected(features.contains(dao.getFeatureIdByName("Air Bags")));
                chkBluetooth.setSelected(features.contains(dao.getFeatureIdByName("Bluetooth")));
                chkHeatedSeats.setSelected(features.contains(dao.getFeatureIdByName("Heated Seats")));

                isCarSearched = true;

            } else {
                JOptionPane.showMessageDialog(this, "No car found with ID: " + carId);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void cmbFuelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFuelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFuelActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner CarIdSpinner;
    private javax.swing.JLabel brandIDLbl;
    private javax.swing.JButton brandListBtn;
    private javax.swing.JButton btnEditCar;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton carListBtn;
    private javax.swing.JCheckBox chkAirBags;
    private javax.swing.JCheckBox chkAirConditioning;
    private javax.swing.JCheckBox chkBluetooth;
    private javax.swing.JCheckBox chkElectricWindows;
    private javax.swing.JCheckBox chkGPS;
    private javax.swing.JCheckBox chkHeatedSeats;
    private javax.swing.JCheckBox chkNavigation;
    private javax.swing.JCheckBox chkSunProof;
    private javax.swing.JComboBox<String> cmbBrand;
    private javax.swing.JComboBox<String> cmbFuel;
    private javax.swing.JButton jButton_Add;
    private javax.swing.JButton jButton_Remove1;
    private javax.swing.JButton jButton_browse;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_brands_logo;
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton rdoAutomatic;
    private javax.swing.JRadioButton rdoManual;
    private javax.swing.JSpinner spinnerPrice;
    private javax.swing.JTextField txtCarClass;
    private javax.swing.JTextField txtColor;
    private javax.swing.JTextField txtModel;
    private javax.swing.JSpinner txtPassengers;
    // End of variables declaration//GEN-END:variables

    private void clearForm() {
        chkAirBags.setSelected(false);
        chkAirConditioning.setSelected(false);
        chkBluetooth.setSelected(false);
        chkHeatedSeats.setSelected(false);
        chkNavigation.setSelected(false);
        chkSunProof.setSelected(false);
        txtColor.setText("");
        txtCarClass.setText("");
        txtModel.setText("");
        rdoAutomatic.setSelected(false);
        rdoManual.setSelected(false);
        txtPassengers.setValue(1);
        spinnerPrice.setValue(0);
        CarIdSpinner.setValue(0);
        cmbBrand.setSelectedIndex(-1);
        cmbFuel.setSelectedIndex(-1);
        brandIDLbl.setText("");
        txtPassengers.setValue(0);
    }
}
