package view;

import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import dao.CarDAO;
import dao.CarImageDAO;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import javax.swing.SwingConstants;
import javax.swing.table.JTableHeader;
import model.Car;
import model.CarImage;

public class CarImages extends javax.swing.JFrame {

    public CarImages() {
        initComponents();
        setTitle("Car Images");
        setLocationRelativeTo(null);

        loadCarsIntoTable();

        imageLbl.setHorizontalAlignment(SwingConstants.CENTER);
        imageLbl.setVerticalAlignment(SwingConstants.CENTER);

        // Costomize table header style
        JTableHeader header = carTable.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 16));
        header.setPreferredSize(new Dimension(header.getWidth(), 30));
        header.setBackground(Color.LIGHT_GRAY);

        JTableHeader header2 = imageIDTable.getTableHeader();
        header2.setFont(new Font("SansSerif", Font.BOLD, 16));
        header2.setPreferredSize(new Dimension(header2.getWidth(), 30));
        header2.setBackground(Color.LIGHT_GRAY);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        carTable = new javax.swing.JTable();
        addImageBtn = new javax.swing.JButton();
        imageSliderBtn = new javax.swing.JButton();
        selectImageBtn = new javax.swing.JButton();
        removeImageBtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        pathLbl = new javax.swing.JLabel();
        imageLbl = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        imageIDTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setText("Selected Car Images");
        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 2, 24)); // NOI18N

        jLabel3.setText("Cars");
        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 2, 24)); // NOI18N

        carTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Model", "Class"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        carTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        carTable.setRowHeight(30);
        carTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(carTable);

        addImageBtn.setText("Add Image");
        addImageBtn.setBackground(new java.awt.Color(0, 153, 0));
        addImageBtn.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        addImageBtn.setForeground(new java.awt.Color(255, 255, 255));
        addImageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addImageBtnActionPerformed(evt);
            }
        });

        imageSliderBtn.setText("Image Slider");
        imageSliderBtn.setBackground(new java.awt.Color(102, 102, 102));
        imageSliderBtn.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        imageSliderBtn.setForeground(new java.awt.Color(255, 255, 255));
        imageSliderBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageSliderBtnActionPerformed(evt);
            }
        });

        selectImageBtn.setText("Select Image");
        selectImageBtn.setBackground(new java.awt.Color(51, 153, 255));
        selectImageBtn.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        selectImageBtn.setForeground(new java.awt.Color(255, 255, 255));
        selectImageBtn.setPreferredSize(new java.awt.Dimension(128, 40));
        selectImageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectImageBtnActionPerformed(evt);
            }
        });

        removeImageBtn.setText("Remove Image");
        removeImageBtn.setBackground(new java.awt.Color(255, 0, 0));
        removeImageBtn.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        removeImageBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeImageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeImageBtnActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(225, 112, 85));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Car Images");
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel_close.setText(" X");
        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(336, 336, 336)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel4)))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pathLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        imageLbl.setBackground(new java.awt.Color(204, 204, 204));
        imageLbl.setMinimumSize(new java.awt.Dimension(32, 32));
        imageLbl.setOpaque(true);

        jScrollPane3.setBackground(new java.awt.Color(255, 255, 255));

        imageIDTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Image ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        imageIDTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        imageIDTable.setRowHeight(30);
        imageIDTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                imageIDTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(imageIDTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(removeImageBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                                .addComponent(imageSliderBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(addImageBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(imageLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(pathLbl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(selectImageBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(30, Short.MAX_VALUE))))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(imageLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pathLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(selectImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(addImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(removeImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(imageSliderBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addImageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addImageBtnActionPerformed
          int carRow = carTable.getSelectedRow();
        if (carRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a car first.");
            return;
        }

        String path = pathLbl.getText();
        if (path == null || path.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select an image.");
            return;
        }

        int carId = (int) carTable.getValueAt(carRow, 0);
        CarImage image = new CarImage();
        image.setCarId(carId);
        image.setImagePath(path);

        if (new CarImageDAO().addImage(image)) {
            JOptionPane.showMessageDialog(this, "Image added successfully.");
            loadImagesByCarId(carId); // Refresh
            pathLbl.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add image.");
        }
    }//GEN-LAST:event_addImageBtnActionPerformed

    private void imageSliderBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageSliderBtnActionPerformed
        int carRow = carTable.getSelectedRow();

        if (carRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a car first.");
            return;
        }

        int carId = (int) carTable.getValueAt(carRow, 0);

        // Open image slider form with selected car ID
        new ImageSlider(carId).setVisible(true);
    }//GEN-LAST:event_imageSliderBtnActionPerformed

    private void selectImageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectImageBtnActionPerformed
        int selectedRow = carTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a car row first.");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            String path = fileChooser.getSelectedFile().getAbsolutePath();
            pathLbl.setText(path);
            ImageIcon icon = new ImageIcon(path);
            Image image = icon.getImage().getScaledInstance(imageLbl.getWidth(), imageLbl.getHeight(), Image.SCALE_SMOOTH);
            imageLbl.setIcon(new ImageIcon(image));
        }
    }//GEN-LAST:event_selectImageBtnActionPerformed

    private void removeImageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeImageBtnActionPerformed
        int imageRow = imageIDTable.getSelectedRow();
        if (imageRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an image ID to remove.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this image?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        int imageId = (int) imageIDTable.getValueAt(imageRow, 0);
        if (new CarImageDAO().deleteImageById(imageId)) {
            JOptionPane.showMessageDialog(this, "Image deleted successfully.");
            int carId = (int) carTable.getValueAt(carTable.getSelectedRow(), 0);
            loadImagesByCarId(carId); // Refresh
            imageLbl.setIcon(null);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete image.");
        }
    }//GEN-LAST:event_removeImageBtnActionPerformed

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void carTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carTableMouseClicked
        int selectedRow = carTable.getSelectedRow();
        if (selectedRow != -1) {
            int carId = (int) carTable.getValueAt(selectedRow, 0);
            loadImagesByCarId(carId);
        }
    }//GEN-LAST:event_carTableMouseClicked

    private void imageIDTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imageIDTableMouseClicked
        int selectedRow = imageIDTable.getSelectedRow();
        if (selectedRow != -1) {
            int imageId = (int) imageIDTable.getValueAt(selectedRow, 0);
            CarImage img = new CarImageDAO().getImageById(imageId);
            displayImage(img.getImagePath());
            pathLbl.setText(img.getImagePath());
        }
    }//GEN-LAST:event_imageIDTableMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addImageBtn;
    private javax.swing.JTable carTable;
    private javax.swing.JTable imageIDTable;
    private javax.swing.JLabel imageLbl;
    private javax.swing.JButton imageSliderBtn;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel pathLbl;
    private javax.swing.JButton removeImageBtn;
    private javax.swing.JButton selectImageBtn;
    // End of variables declaration//GEN-END:variables

    private void loadCarsIntoTable() {
        DefaultTableModel model = (DefaultTableModel) carTable.getModel();
        model.setRowCount(0); // Clear existing rows
        List<Car> cars = new CarDAO().getAllCars();

        for (Car car : cars) {
            model.addRow(new Object[]{car.getId(), car.getModel(), car.getCarClass()});
        }
    }

    private void loadImagesByCarId(int carId) {
        DefaultTableModel model = (DefaultTableModel) imageIDTable.getModel();
        model.setRowCount(0);
        List<CarImage> currentImageList = new CarImageDAO().getImagesByCarId(carId);

        for (CarImage img : currentImageList) {
            model.addRow(new Object[]{img.getId()});
        }
    }

    private void displayImage(String path) {
        ImageIcon icon = new ImageIcon(path);
        Image image = icon.getImage().getScaledInstance(imageLbl.getWidth(), imageLbl.getHeight(), Image.SCALE_SMOOTH);
        imageLbl.setIcon(new ImageIcon(image));
    }
}







