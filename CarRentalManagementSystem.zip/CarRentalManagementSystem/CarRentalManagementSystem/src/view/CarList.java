package view;

import dao.BrandDAO;
import dao.CarDAO;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.List;
import java.util.Map;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import model.Car;

public class CarList extends javax.swing.JFrame {

    private Map<String, Integer> brandMap;
    private BookCarForm bookCar;
    Car selectedCar = new Car();
    private boolean isBrowseEnabledOnSelect;

    private BookingEdit bookingEdit; // Add this

    public CarList(BookingEdit bookingEdit, String brandName, boolean isBrowseEnabledOnSelect) {
        brandMap = new BrandDAO().getAllBrandNameIdMap();
        initComponents();
        setTitle("Car List");
        setLocationRelativeTo(null);
        this.bookingEdit = bookingEdit;
        this.isBrowseEnabledOnSelect = isBrowseEnabledOnSelect;
        jButton_browse.setEnabled(isBrowseEnabledOnSelect);
        if (brandName != null && brandMap.containsKey(brandName)) {
            loadCarListData(brandName);
        } else {
            loadCarListData();
        }
    }

    public CarList(BookCarForm bookCar, boolean isBrowseEnabledOnSelect, int brandId) {
        initComponents();
        setTitle("Car List");
        setLocationRelativeTo(null);
        this.bookCar = bookCar;
        this.isBrowseEnabledOnSelect = isBrowseEnabledOnSelect;
        loadCarsByBrand(brandId);

        // Customize table header
        JTableHeader header = carListTable.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 16));
        header.setPreferredSize(new Dimension(header.getWidth(), 30));
        header.setBackground(Color.LIGHT_GRAY);
    }

    public CarList(BookCarForm bookCar, boolean isBrowseEnabledOnSelect) {
        this(bookCar, isBrowseEnabledOnSelect, null); // default for BookCarForm use
    }

    public CarList(BookCarForm bookCar, boolean isBrowseEnabledOnSelect, String brandName) {
        initComponents();
        setTitle("Car List");
        setLocationRelativeTo(null);
        this.bookCar = bookCar;
        this.isBrowseEnabledOnSelect = isBrowseEnabledOnSelect;
        jButton_browse.setEnabled(isBrowseEnabledOnSelect); // only enabled for BookCarForm

        brandMap = new BrandDAO().getAllBrandNameIdMap();

        // Customize table header
        JTableHeader header = carListTable.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 16));
        header.setPreferredSize(new Dimension(header.getWidth(), 30));
        header.setBackground(Color.LIGHT_GRAY);

        if (brandName != null && brandMap.containsKey(brandName)) {
            loadCarListData(brandName);
        } else {
            loadCarListData();
        }

    }

    private void loadCarListData() {
        String selectedBrand = (String) bookCar.cmbCarBrand.getSelectedItem();
        loadCarListData(selectedBrand);
    }

    private void loadCarListData(String brandName) {
        if (brandName == null || !brandMap.containsKey(brandName)) {
            return;
        }

        int brandId = brandMap.get(brandName);
        List<Car> brandCars = new CarDAO().getCarsByBrandId(brandId);

        String[] columnNames = {"Car ID", "Model", "Fuel", "Color", "Price/Day"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (Car car : brandCars) {
            Object[] rowData = {
                car.getId(),
                car.getModel(),
                car.getFuel().toString(),
                car.getColor(),
                car.getPricePerDay()
            };
            model.addRow(rowData);
        }
        carListTable.setModel(model);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_brands_logo = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        carListTable = new javax.swing.JTable();
        jButton_browse = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 5));

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Car List By Brand");
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel_brands_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/cList.png"))); // NOI18N

        jLabel_close.setText(" X");
        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel_brands_logo)
                .addGap(95, 95, 95)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_brands_logo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        carListTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        carListTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Model", "Fuel", "Color", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        carListTable.setRowHeight(30);
        carListTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carListTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(carListTable);

        jButton_browse.setText("Select Car");
        jButton_browse.setBackground(new java.awt.Color(102, 102, 102));
        jButton_browse.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton_browse.setForeground(new java.awt.Color(255, 255, 255));
        jButton_browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_browseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 539, Short.MAX_VALUE)
                    .addComponent(jButton_browse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton_browse, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 27, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void jButton_browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_browseActionPerformed
        String id = Integer.toString(selectedCar.getId());
        String pricePerDay = Integer.toString(selectedCar.getPricePerDay());
        String model = selectedCar.getModel();
        if (bookCar != null) {
            bookCar.lblCarId.setText(id);
            bookCar.lblPrice.setText(pricePerDay);
            bookCar.lblModel.setText(model);
        }

        if (bookingEdit != null) {
            bookingEdit.lblCarID.setText(id);
            bookingEdit.lblPrice.setText(pricePerDay);
            bookingEdit.lblModel.setText(model);
        }
        dispose();
    }//GEN-LAST:event_jButton_browseActionPerformed

    private void carListTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carListTableMouseClicked
        int selectedRow = carListTable.getSelectedRow();
        try {
            if (selectedRow != -1) {
                int CarId = (int) carListTable.getValueAt(selectedRow, 0);
                selectedCar = new CarDAO().searchCar(CarId);
                jButton_browse.setEnabled(isBrowseEnabledOnSelect);

            }
        } catch (Exception ex) {
            ex.getMessage();
        }
    }//GEN-LAST:event_carListTableMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable carListTable;
    private javax.swing.JButton jButton_browse;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel_brands_logo;
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private void loadCarsByBrand(int brandId) {
        try {
            CarDAO carDAO = new CarDAO();
            List<Car> cars = carDAO.getCarsByBrandId(brandId);
            DefaultTableModel model = (DefaultTableModel) carListTable.getModel();
            model.setRowCount(0);

            for (Car car : cars) {
                model.addRow(new Object[]{
                    car.getId(),
                    car.getModel(),
                    car.getFuel().toString(),
                    car.getColor(),
                    car.getPricePerDay()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
