package view;

import dao.BookCarDAO;
import dao.BrandDAO;
import dao.CarDAO;
import dao.CityAddressDAO;
import dao.CustomerDAO;
import dao.LocationDAO;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import model.BookCar;
import model.Brand;
import model.Car;
import model.CityAddress;
import model.Customer;
import java.util.Date;

public class BookingEdit extends javax.swing.JFrame {

    Dashboard dashboard;
    //private BookCarForm bookCar = new BookCarForm();
    private BookCarForm bookCar;
    private Map<String, Integer> brandMap;

    public BookingEdit(Dashboard dashboard) {
        initComponents();
        setTitle("Booking Edit");
        setLocationRelativeTo(null);
        clearFormFields();
        loadCities();
        loadDataById();
        this.dashboard = dashboard;
        dashboard.refreshDashboardCounts();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_brands_logo = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton_Edit = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        lblBookingID = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cmbPickupCity = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        pickupDatePicker = new com.toedter.calendar.JDateChooser();
        cmbPickupAddress = new javax.swing.JComboBox<>();
        pickupTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        jPanel6 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtCustomerName = new javax.swing.JTextField();
        customerID = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        selectCustomerBtn = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        cmbDropoffCity = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        cmbDropoffAddress = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        dropoffDatePicker = new com.toedter.calendar.JDateChooser();
        jLabel20 = new javax.swing.JLabel();
        dropoffTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        jPanel1 = new javax.swing.JPanel();
        totalLbl = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        calculateButton = new javax.swing.JButton();
        jButton_Edit1 = new javax.swing.JButton();
        jButton_Remove1 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        selectCarByBrandBtn = new javax.swing.JButton();
        jLabel58 = new javax.swing.JLabel();
        brandID = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        lblModel = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        lblCarID = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        cmbCarBrand = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 5));

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Booking Edit / Remove");
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel_brands_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/bookingC.png"))); // NOI18N

        jLabel_close.setText(" X");
        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel_brands_logo)
                .addGap(232, 232, 232)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel_brands_logo)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));

        jButton_Edit.setText("Booking List");
        jButton_Edit.setBackground(new java.awt.Color(102, 102, 102));
        jButton_Edit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Edit.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_EditActionPerformed(evt);
            }
        });

        jLabel12.setText("Select Booking :");
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel28.setText("ID");
        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblBookingID.setText("000");
        lblBookingID.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel12)
                .addGap(27, 27, 27)
                .addComponent(jButton_Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblBookingID)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_Edit)
                    .addComponent(jLabel12)
                    .addComponent(jLabel28)
                    .addComponent(lblBookingID))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jLabel3.setText("City:");
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        cmbPickupCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbPickupCity.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbPickupCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPickupCityActionPerformed(evt);
            }
        });

        jLabel5.setText("Time:");
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel11.setText("Pickup Location & Date");
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        jLabel14.setText("Address:");
        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel15.setText("Date:");
        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        pickupDatePicker.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        pickupDatePicker.setPreferredSize(new java.awt.Dimension(94, 28));

        cmbPickupAddress.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbPickupAddress.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbPickupAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPickupAddressActionPerformed(evt);
            }
        });

        pickupTimePicker.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        pickupTimePicker.setPreferredSize(new java.awt.Dimension(90, 28));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel15)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pickupTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbPickupCity, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbPickupAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pickupDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbPickupCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cmbPickupAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(pickupDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pickupTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));

        jLabel7.setText("Customer:");
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel13.setText("Select Customer");
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        txtCustomerName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        customerID.setText("000");
        customerID.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel9.setText("ID");
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        selectCustomerBtn.setText("Select Customer");
        selectCustomerBtn.setBackground(new java.awt.Color(102, 102, 102));
        selectCustomerBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        selectCustomerBtn.setForeground(new java.awt.Color(255, 255, 255));
        selectCustomerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectCustomerBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(174, 174, 174)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(customerID)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(selectCustomerBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(84, 84, 84))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel13)
                .addGap(9, 9, 9)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(selectCustomerBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(customerID)
                    .addComponent(jLabel9))
                .addGap(17, 17, 17))
        );

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));

        jLabel18.setText("Drop Off Location & Date");
        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        jLabel16.setText("City:");
        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        cmbDropoffCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbDropoffCity.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbDropoffCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbDropoffCityActionPerformed(evt);
            }
        });

        jLabel17.setText("Address:");
        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        cmbDropoffAddress.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbDropoffAddress.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbDropoffAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbDropoffAddressActionPerformed(evt);
            }
        });

        jLabel19.setText("Date:");
        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        dropoffDatePicker.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        dropoffDatePicker.setPreferredSize(new java.awt.Dimension(94, 28));

        jLabel20.setText("Time:");
        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        dropoffTimePicker.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        dropoffTimePicker.setPreferredSize(new java.awt.Dimension(90, 28));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20)
                    .addComponent(jLabel16)
                    .addComponent(jLabel19)
                    .addComponent(jLabel17))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dropoffTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbDropoffCity, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbDropoffAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dropoffDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(cmbDropoffCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(cmbDropoffAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(dropoffDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dropoffTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20))))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        totalLbl.setText("00000");
        totalLbl.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel22.setText("Total Price:");
        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        calculateButton.setText("Calculate");
        calculateButton.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        calculateButton.setForeground(new java.awt.Color(0, 0, 51));
        calculateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(calculateButton)
                .addGap(19, 19, 19))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(totalLbl)
                    .addComponent(calculateButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jButton_Edit1.setText("Edit Booking");
        jButton_Edit1.setBackground(new java.awt.Color(0, 153, 255));
        jButton_Edit1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Edit1.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Edit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Edit1ActionPerformed(evt);
            }
        });

        jButton_Remove1.setText("Remove / Cancel Booking");
        jButton_Remove1.setBackground(new java.awt.Color(204, 0, 0));
        jButton_Remove1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Remove1.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Remove1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Remove1ActionPerformed(evt);
            }
        });

        jPanel10.setBackground(new java.awt.Color(204, 204, 204));

        jLabel55.setText("Brand:");
        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel56.setText("Select a Car");
        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N

        jLabel57.setText("ID");
        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        selectCarByBrandBtn.setText("Select Car");
        selectCarByBrandBtn.setBackground(new java.awt.Color(102, 102, 102));
        selectCarByBrandBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        selectCarByBrandBtn.setForeground(new java.awt.Color(255, 255, 255));
        selectCarByBrandBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectCarByBrandBtnActionPerformed(evt);
            }
        });

        jLabel58.setText("Car:");
        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        brandID.setText("1");
        brandID.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel60.setText("Price:");
        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel61.setText("Model:");
        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblModel.setText("###");
        lblModel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblPrice.setText("000");
        lblPrice.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel64.setText("ID");
        jLabel64.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblCarID.setText("000");
        lblCarID.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel66.setText("|");
        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(204, 102, 0));

        cmbCarBrand.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCarBrand.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbCarBrand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCarBrandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel55)
                        .addGap(18, 18, 18)
                        .addComponent(cmbCarBrand, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel61)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblModel))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel58)
                                .addGap(18, 18, 18)
                                .addComponent(selectCarByBrandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel64)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblCarID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel66)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel60)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPrice))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel57)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(brandID)))
                .addGap(0, 124, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(161, 161, 161))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel56)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel55)
                    .addComponent(jLabel57)
                    .addComponent(brandID)
                    .addComponent(cmbCarBrand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectCarByBrandBtn)
                    .addComponent(jLabel58)
                    .addComponent(jLabel64)
                    .addComponent(lblCarID)
                    .addComponent(jLabel66)
                    .addComponent(jLabel60)
                    .addComponent(lblPrice))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(lblModel))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton_Remove1, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(jButton_Edit1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(47, 47, 47)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton_Remove1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_Edit1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void jButton_Remove1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Remove1ActionPerformed
        // Validate if a booking is selected
        String bookingIdText = lblBookingID.getText().trim();

        if (bookingIdText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a booking to remove.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this booking?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int bookingId = Integer.parseInt(bookingIdText);
            BookCarDAO bookingDAO = new BookCarDAO();

            boolean deleted = bookingDAO.deleteBooking(bookingId);

            if (deleted) {
                JOptionPane.showMessageDialog(this, "Booking removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                dashboard.refreshDashboardCounts();
                clearFormFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to remove the booking.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid booking ID.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error occurred while deleting the booking.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton_Remove1ActionPerformed

    private void jButton_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_EditActionPerformed
        new BookingList(this).setVisible(true);
    }//GEN-LAST:event_jButton_EditActionPerformed

    private void cmbPickupCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPickupCityActionPerformed
        String selectedCity = (String) cmbPickupCity.getSelectedItem();
        if (selectedCity != null) {
            LocationDAO locationDAO = new LocationDAO();
            CityAddressDAO addressDAO = new CityAddressDAO();

            try {
                int cityId = locationDAO.getCityMap().get(selectedCity);
                List<String> addresses = addressDAO.getAddressesByCityId(cityId);
                cmbPickupAddress.setModel(new DefaultComboBoxModel<>(addresses.toArray(new String[0])));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_cmbPickupCityActionPerformed

    private void cmbPickupAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPickupAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbPickupAddressActionPerformed

    private void selectCustomerBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectCustomerBtnActionPerformed
        new CustomerList(this).setVisible(true);
    }//GEN-LAST:event_selectCustomerBtnActionPerformed

    private void cmbDropoffCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDropoffCityActionPerformed
        String selectedCity = (String) cmbDropoffCity.getSelectedItem();
        if (selectedCity != null) {
            LocationDAO locationDAO = new LocationDAO();
            CityAddressDAO addressDAO = new CityAddressDAO();

            try {
                int cityId = locationDAO.getCityMap().get(selectedCity);
                List<String> addresses = addressDAO.getAddressesByCityId(cityId);
                cmbDropoffAddress.setModel(new DefaultComboBoxModel<>(addresses.toArray(new String[0])));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_cmbDropoffCityActionPerformed

    private void cmbDropoffAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDropoffAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbDropoffAddressActionPerformed

    private void calculateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateButtonActionPerformed
        try {
            if (pickupDatePicker.getDate() == null || dropoffDatePicker.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please select both pickup and return dates.");
                return;
            }

            if (lblPrice.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Car price is not available.");
                return;
            }

            int pricePerDay = Integer.parseInt(lblPrice.getText());
            int totalPrice = calculateTotalPrice(pricePerDay);

            totalLbl.setText(String.valueOf(totalPrice));

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error calculating total price: " + e.getMessage());
        }
    }//GEN-LAST:event_calculateButtonActionPerformed

    private void jButton_Edit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Edit1ActionPerformed
        try {
            // Validate Booking ID
            int bookingId = Integer.parseInt(lblBookingID.getText());

            // Validate required fields (example only)
            if (txtCustomerName.getText().trim().isEmpty()
                    || pickupDatePicker.getDate() == null
                    || dropoffDatePicker.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please fill all required fields", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Construct LocalDateTime
            LocalDate pickupDate = new java.sql.Date(pickupDatePicker.getDate().getTime()).toLocalDate();
            LocalTime pickupTime = pickupTimePicker.getTime();
            LocalDateTime pickupDateTime = LocalDateTime.of(pickupDate, pickupTime);

            LocalDate dropoffDate = new java.sql.Date(dropoffDatePicker.getDate().getTime()).toLocalDate();
            LocalTime dropoffTime = dropoffTimePicker.getTime();
            LocalDateTime dropoffDateTime = LocalDateTime.of(dropoffDate, dropoffTime);

            // Prepare updated booking object
            BookCar booking = new BookCar();
            booking.setId(bookingId);
            booking.setCarId(Integer.parseInt(lblCarID.getText()));
            booking.setCustomerId(Integer.parseInt(customerID.getText()));
            booking.setPickupCityId(cmbPickupCity.getSelectedIndex() + 1); // Adjust based on real ID
            booking.setPickupAddressId(cmbPickupAddress.getSelectedIndex() + 1);
            booking.setDropoffCityId(cmbDropoffCity.getSelectedIndex() + 1);
            booking.setDropoffAddressId(cmbDropoffAddress.getSelectedIndex() + 1);
            booking.setPickupDateTime(pickupDateTime);
            booking.setReturnDateTime(dropoffDateTime);
            booking.setTotalPrice(Integer.parseInt(totalLbl.getText()));

            BookCarDAO dao = new BookCarDAO();
            boolean success = dao.updateBooking(booking);

            if (success) {
                JOptionPane.showMessageDialog(this, "Booking updated successfully!");
                // Optionally refresh table or clear fields
            } else {
                JOptionPane.showMessageDialog(this, "Update failed. Please try again.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid numeric value", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Exception", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton_Edit1ActionPerformed

    private void selectCarByBrandBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectCarByBrandBtnActionPerformed
        String selectedBrand = (String) cmbCarBrand.getSelectedItem();
        if (selectedBrand != null && brandMap != null) {
            Integer id = brandMap.get(selectedBrand);

            Brand brand = new BrandDAO().getBrandById(id);
            if (id != null) {
                brandID.setText(String.valueOf(id));
                new CarList(this, brand.getBrandName(), true).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Brand ID not found for selected brand.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a brand.");
        }
    }//GEN-LAST:event_selectCarByBrandBtnActionPerformed

    private void cmbCarBrandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCarBrandActionPerformed
        String selectedBrand = (String) cmbCarBrand.getSelectedItem();
        if (selectedBrand != null && brandMap != null) {
            Integer id = brandMap.get(selectedBrand);
            if (id != null) {
                brandID.setText(String.valueOf(id));
            } else {
                brandID.setText("N/A");
            }
        }
    }//GEN-LAST:event_cmbCarBrandActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel brandID;
    private javax.swing.JButton calculateButton;
    private javax.swing.JComboBox<String> cmbCarBrand;
    private javax.swing.JComboBox<String> cmbDropoffAddress;
    private javax.swing.JComboBox<String> cmbDropoffCity;
    private javax.swing.JComboBox<String> cmbPickupAddress;
    private javax.swing.JComboBox<String> cmbPickupCity;
    public javax.swing.JLabel customerID;
    private com.toedter.calendar.JDateChooser dropoffDatePicker;
    private com.github.lgooddatepicker.components.TimePicker dropoffTimePicker;
    private javax.swing.JButton jButton_Edit;
    private javax.swing.JButton jButton_Edit1;
    private javax.swing.JButton jButton_Remove1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_brands_logo;
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    public javax.swing.JLabel lblBookingID;
    public javax.swing.JLabel lblCarID;
    public javax.swing.JLabel lblModel;
    public javax.swing.JLabel lblPrice;
    private com.toedter.calendar.JDateChooser pickupDatePicker;
    private com.github.lgooddatepicker.components.TimePicker pickupTimePicker;
    private javax.swing.JButton selectCarByBrandBtn;
    private javax.swing.JButton selectCustomerBtn;
    private javax.swing.JLabel totalLbl;
    public javax.swing.JTextField txtCustomerName;
    // End of variables declaration//GEN-END:variables

    public void loadDataById() {
        loadBrands();
        String idText = lblBookingID.getText().trim();
        if (idText.isEmpty()) {
            return;
        }

        try {
            int bookingId = Integer.parseInt(idText);
            BookCar booking = new BookCarDAO().editBookingById(bookingId);

            if (booking != null) {
                // // ----- Load Brand combo box -----
                Map<String, Integer> brandMap = new BrandDAO().getAllBrandNameIdMap();
                cmbCarBrand.setModel(new DefaultComboBoxModel<>(brandMap.keySet().toArray(new String[0])));

                // ----- Load Car Details -----
                int carId = booking.getCarId();
                Car car = new CarDAO().searchCar(carId);
                Brand brand = new BrandDAO().getBrandById(car.getBrandId());

                cmbCarBrand.setSelectedItem(brand.getBrandName());
                lblCarID.setText(String.valueOf(carId));
                lblModel.setText(car.getModel());
                lblPrice.setText(String.valueOf(car.getPricePerDay()));

                // ----- Load Customer -----
                Customer customer = new CustomerDAO().getCustomerById(booking.getCustomerId());
                customerID.setText(String.valueOf(customer.getId()));
                txtCustomerName.setText(customer.getName());

                // ----- Load Pickup/Drop-off Cities -----
                loadCities(); // This fills city combo boxes with all city names

                // ----- Load Pickup and Dropoff Location and Address -----
                loadPickupAndDropoffLocations(booking.getPickupAddressId(), booking.getDropoffAddressId());

                // ----- Load Pickup Date & Time -----
                LocalDateTime pickupDateTime = booking.getPickupDateTime();
                Date pickupDate = Date.from(pickupDateTime.atZone(ZoneId.systemDefault()).toInstant());
                pickupDatePicker.setDate(pickupDate);
                pickupTimePicker.setTime(pickupDateTime.toLocalTime());

                // ----- Load Return Date & Time -----
                LocalDateTime returnDateTime = booking.getReturnDateTime();
                Date returnDate = Date.from(returnDateTime.atZone(ZoneId.systemDefault()).toInstant());
                dropoffDatePicker.setDate(returnDate);
                dropoffTimePicker.setTime(returnDateTime.toLocalTime());

                // ----- Set Brand ID in Label -----
                brandID.setText(String.valueOf(brand.getId()));

                // ----- Calculate and Set Total Price -----
                try {
                    int total = calculateTotalPrice(car.getPricePerDay());
                    totalLbl.setText(String.valueOf(total));
                } catch (IllegalArgumentException e) {
                    totalLbl.setText("N/A");
                    System.err.println("Could not calculate total price: " + e.getMessage());
                }

            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid Booking ID format.");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load booking data.");
        }
    }

    private void loadPickupAndDropoffLocations(int pickupAddressId, int dropoffAddressId) {
        try {
            CityAddressDAO addressDAO = new CityAddressDAO();
            LocationDAO locationDAO = new LocationDAO();

            // ----- Load Pickup -----
            CityAddress pickupAddress = addressDAO.getAddressByID(pickupAddressId);
            if (pickupAddress != null) {
                String pickupCityName = locationDAO.getCityNameById(pickupAddress.getLocationId());

                // Set selected city in combo
                cmbPickupCity.setSelectedItem(pickupCityName);

                // Now load addresses for selected city and set selected address
                List<String> pickupAddresses = addressDAO.getAddressesByCityId(pickupAddress.getLocationId());
                cmbPickupAddress.setModel(new DefaultComboBoxModel<>(pickupAddresses.toArray(new String[0])));
                cmbPickupAddress.setSelectedItem(pickupAddress.getAddress());
            }

            // ----- Load Drop-off -----
            CityAddress dropoffAddress = addressDAO.getAddressByID(dropoffAddressId);
            if (dropoffAddress != null) {
                String dropoffCityName = locationDAO.getCityNameById(dropoffAddress.getLocationId());

                // Set selected city in combo
                cmbDropoffCity.setSelectedItem(dropoffCityName);

                // Now load addresses for selected city and set selected address
                List<String> dropoffAddresses = addressDAO.getAddressesByCityId(dropoffAddress.getLocationId());
                cmbDropoffAddress.setModel(new DefaultComboBoxModel<>(dropoffAddresses.toArray(new String[0])));
                cmbDropoffAddress.setSelectedItem(dropoffAddress.getAddress());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadCities() {
        LocationDAO locationDAO = new LocationDAO();
        List<String> cities = locationDAO.getAllCities();

        cmbPickupCity.setModel(new DefaultComboBoxModel<>(cities.toArray(new String[0])));
        cmbDropoffCity.setModel(new DefaultComboBoxModel<>(cities.toArray(new String[0])));
    }

    private int calculateTotalPrice(int pricePerDay) {
        Date pickupDate = pickupDatePicker.getDate();
        Date returnDate = dropoffDatePicker.getDate();
        LocalTime pickupTime = pickupTimePicker.getTime();
        LocalTime returnTime = dropoffTimePicker.getTime();

        if (pickupDate == null || returnDate == null || pickupTime == null || returnTime == null) {
            throw new IllegalArgumentException("Pickup and return date/time must be selected.");
        }

        LocalDateTime pickupDateTime = LocalDateTime.of(
                pickupDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
                pickupTime
        );

        LocalDateTime returnDateTime = LocalDateTime.of(
                returnDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
                returnTime
        );

        if (pickupDateTime.isAfter(returnDateTime)) {
            throw new IllegalArgumentException("Pickup date/time must be before return date/time.");
        }

        long totalHours = ChronoUnit.HOURS.between(pickupDateTime, returnDateTime);

        // Round up to the next full day if there's a partial day
        long totalDays = (long) Math.ceil(totalHours / 24.0);

        return (int) (totalDays * pricePerDay);
    }

    private void clearFormFields() {
        // ComboBoxes
        cmbCarBrand.setSelectedIndex(-1);
        brandID.setText("");

        cmbPickupCity.setSelectedIndex(-1);
        cmbPickupAddress.removeAllItems();

        cmbDropoffCity.setSelectedIndex(-1);
        cmbDropoffAddress.removeAllItems();

        // DatePickers
        pickupDatePicker.setDate(null);
        dropoffDatePicker.setDate(null);

        // TimePickers
        pickupTimePicker.setTime(null);
        dropoffTimePicker.setTime(null);

        // Labels
        lblCarID.setText("");
        customerID.setText("");
        lblModel.setText("");
        lblPrice.setText("");
        totalLbl.setText("");

        // Text fields
        txtCustomerName.setText("");
    }

    private void loadBrands() {
        BrandDAO brandDAO = new BrandDAO();
        brandMap = brandDAO.getAllBrandNameIdMap(); // map: brand name -> brand ID
        cmbCarBrand.setModel(new DefaultComboBoxModel<>(brandMap.keySet().toArray(new String[0])));
    }
}
