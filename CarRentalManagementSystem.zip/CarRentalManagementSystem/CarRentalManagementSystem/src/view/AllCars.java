package view;

import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import dao.CarDAO;
import dao.CarImageDAO;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import model.Car;
import java.awt.Image;
import javax.swing.table.JTableHeader;

public class AllCars extends javax.swing.JFrame {

    public AllCars() {
        initComponents();
        setTitle("All Car");
        setLocationRelativeTo(null);

        setupSmallImageListeners();

        // Costomize table header style
        JTableHeader header = carTable.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 16));
        header.setPreferredSize(new Dimension(header.getWidth(), 30));
        header.setBackground(Color.LIGHT_GRAY);

        loadCarTableData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_brands_logo = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        carTable = new javax.swing.JTable();
        imageSliderBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        smallImg1Lbl = new javax.swing.JLabel();
        smallImg2Lbl = new javax.swing.JLabel();
        smallImg3Lbl = new javax.swing.JLabel();
        smallImg4Lbl = new javax.swing.JLabel();
        smallImg5Lbl = new javax.swing.JLabel();
        smallImg6Lbl = new javax.swing.JLabel();
        bigImageLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 5));

        jPanel3.setBackground(new java.awt.Color(225, 112, 85));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("All Cars");

        jLabel_brands_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/list.png"))); // NOI18N

        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.setText(" X");
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel_brands_logo)
                .addGap(341, 341, 341)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_brands_logo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        carTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        carTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Brand", "Model", "Fuel", "Color", "Class", "Passengers", "Gearbox", "Price", "Air Conditioning", "Air Bags", "Sunroof", "Heated Seats", "Navigation Systems", "Bluetooth", "Electric Windows", "GPS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        carTable.setRowHeight(30);
        carTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(carTable);

        imageSliderBtn.setBackground(new java.awt.Color(0, 153, 255));
        imageSliderBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        imageSliderBtn.setForeground(new java.awt.Color(255, 255, 255));
        imageSliderBtn.setText("Image Slider");
        imageSliderBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageSliderBtnActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));

        smallImg1Lbl.setBackground(new java.awt.Color(255, 255, 255));
        smallImg1Lbl.setMinimumSize(new java.awt.Dimension(40, 20));
        smallImg1Lbl.setOpaque(true);
        smallImg1Lbl.setPreferredSize(new java.awt.Dimension(40, 20));

        smallImg2Lbl.setBackground(new java.awt.Color(255, 255, 255));
        smallImg2Lbl.setMinimumSize(new java.awt.Dimension(40, 20));
        smallImg2Lbl.setOpaque(true);
        smallImg2Lbl.setPreferredSize(new java.awt.Dimension(40, 20));

        smallImg3Lbl.setBackground(new java.awt.Color(255, 255, 255));
        smallImg3Lbl.setMinimumSize(new java.awt.Dimension(40, 20));
        smallImg3Lbl.setOpaque(true);
        smallImg3Lbl.setPreferredSize(new java.awt.Dimension(40, 20));

        smallImg4Lbl.setBackground(new java.awt.Color(255, 255, 255));
        smallImg4Lbl.setMinimumSize(new java.awt.Dimension(40, 20));
        smallImg4Lbl.setOpaque(true);
        smallImg4Lbl.setPreferredSize(new java.awt.Dimension(40, 20));

        smallImg5Lbl.setBackground(new java.awt.Color(255, 255, 255));
        smallImg5Lbl.setMinimumSize(new java.awt.Dimension(40, 20));
        smallImg5Lbl.setOpaque(true);
        smallImg5Lbl.setPreferredSize(new java.awt.Dimension(40, 20));

        smallImg6Lbl.setBackground(new java.awt.Color(255, 255, 255));
        smallImg6Lbl.setMinimumSize(new java.awt.Dimension(40, 20));
        smallImg6Lbl.setOpaque(true);
        smallImg6Lbl.setPreferredSize(new java.awt.Dimension(40, 20));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(smallImg1Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(smallImg2Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(smallImg3Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(smallImg4Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(smallImg5Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(smallImg6Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(smallImg3Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(smallImg6Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(smallImg2Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(smallImg5Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(smallImg1Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(smallImg4Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        bigImageLbl.setBackground(new java.awt.Color(204, 204, 204));
        bigImageLbl.setMinimumSize(new java.awt.Dimension(40, 20));
        bigImageLbl.setOpaque(true);
        bigImageLbl.setPreferredSize(new java.awt.Dimension(40, 20));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 958, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(imageSliderBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bigImageLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(bigImageLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(imageSliderBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 418, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void imageSliderBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageSliderBtnActionPerformed
        int selectedRow = carTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a car row first", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int carId = Integer.parseInt(carTable.getValueAt(selectedRow, 0).toString());
        new ImageSlider(carId).setVisible(true);
    }//GEN-LAST:event_imageSliderBtnActionPerformed

    private void carTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carTableMouseClicked
        int selectedRow = carTable.getSelectedRow();
        if (selectedRow >= 0) {
            int carId = Integer.parseInt(carTable.getValueAt(selectedRow, 0).toString());
            loadCarImages(carId);
        }
    }//GEN-LAST:event_carTableMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bigImageLbl;
    private javax.swing.JTable carTable;
    private javax.swing.JButton imageSliderBtn;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel_brands_logo;
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel smallImg1Lbl;
    private javax.swing.JLabel smallImg2Lbl;
    private javax.swing.JLabel smallImg3Lbl;
    private javax.swing.JLabel smallImg4Lbl;
    private javax.swing.JLabel smallImg5Lbl;
    private javax.swing.JLabel smallImg6Lbl;
    // End of variables declaration//GEN-END:variables

    private void loadCarImages(int carId) {
        List<String> imagePaths = CarImageDAO.getImagesListByCarId(carId);
        JLabel[] labels = {smallImg1Lbl, smallImg2Lbl, smallImg3Lbl, smallImg4Lbl, smallImg5Lbl, smallImg6Lbl};

        for (int i = 0; i < labels.length; i++) {
            if (i < imagePaths.size()) {
                ImageIcon icon = new ImageIcon(imagePaths.get(i));
                Image scaled = icon.getImage().getScaledInstance(labels[i].getWidth(), labels[i].getHeight(), Image.SCALE_SMOOTH);
                labels[i].setIcon(new ImageIcon(scaled));
                labels[i].setToolTipText(imagePaths.get(i));
            } else {
                labels[i].setIcon(null);
                labels[i].setToolTipText(null);
            }
        }

        if (!imagePaths.isEmpty()) {
            // Set first image as big preview
            ImageIcon firstIcon = new ImageIcon(imagePaths.get(0));
            Image scaledBig = firstIcon.getImage().getScaledInstance(bigImageLbl.getWidth(), bigImageLbl.getHeight(), Image.SCALE_SMOOTH);
            bigImageLbl.setIcon(new ImageIcon(scaledBig));
        } else {
            bigImageLbl.setIcon(null);
        }
    }

    private void setupSmallImageListeners() {
        JLabel[] smallLabels = {smallImg1Lbl, smallImg2Lbl, smallImg3Lbl, smallImg4Lbl, smallImg5Lbl, smallImg6Lbl};

        for (JLabel lbl : smallLabels) {
            lbl.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    String path = lbl.getToolTipText(); // previously set path
                    if (path != null) {
                        ImageIcon icon = new ImageIcon(path);
                        Image scaled = icon.getImage().getScaledInstance(bigImageLbl.getWidth(), bigImageLbl.getHeight(), Image.SCALE_SMOOTH);
                        bigImageLbl.setIcon(new ImageIcon(scaled));
                    }
                }
            });
        }
    }

    private void loadCarTableData() {
        CarDAO carDAO = new CarDAO();
        List<Car> cars = carDAO.getAllCars();

        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) carTable.getModel();
        model.setRowCount(0); // clear table

        for (Car car : cars) {
            // Convert feature IDs to boolean columns
            boolean[] features = new boolean[8];
            for (int fid : car.getFeatureIds()) {
                if (fid >= 1 && fid <= 8) {
                    features[fid - 1] = true;
                }
            }

            model.addRow(new Object[]{
                car.getId(),
                car.getBrandId(),
                car.getModel(),
                car.getFuel(),
                car.getColor(),
                car.getCarClass(),
                car.getPassengers(),
                car.getGearbox(),
                car.getPricePerDay(),
                features[0], // Air Conditioning
                features[1], // Air Bags
                features[2], // Sunroof
                features[3], // Heated Seats
                features[4], // Navigation
                features[5], // Bluetooth
                features[6], // Electric Windows
                features[7] // GPS
            });
        }
    }

}
