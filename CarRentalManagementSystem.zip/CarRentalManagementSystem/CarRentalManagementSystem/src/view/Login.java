package view;

import dao.UserDAO;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        setTitle("Login");
        setLocationRelativeTo(null);

        jLabel_title.setBorder(new MatteBorder(0, 0, 3, 0, Color.RED));

        // Load and scale icons
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("/icons/user.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(30, -1, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        profileIconLbl.setIcon(scaledIcon);
        profileIconLbl.setHorizontalAlignment(SwingConstants.CENTER);
        profileIconLbl.setVerticalAlignment(SwingConstants.CENTER);

        ImageIcon originalIcon2 = new ImageIcon(getClass().getResource("/icons/unlock.png"));
        Image scaledImage2 = originalIcon2.getImage().getScaledInstance(30, -1, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon2 = new ImageIcon(scaledImage2);
        passIconLbl.setIcon(scaledIcon2);
        passIconLbl.setHorizontalAlignment(SwingConstants.CENTER);
        passIconLbl.setVerticalAlignment(SwingConstants.CENTER);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel_logo = new javax.swing.JLabel();
        jLabel_title = new javax.swing.JLabel();
        userNameTxt = new javax.swing.JTextField();
        showPasswordCheckBox = new javax.swing.JCheckBox();
        loginBtn = new javax.swing.JButton();
        jLabel_close = new javax.swing.JLabel();
        passwordTxt = new javax.swing.JPasswordField();
        profileIconLbl = new javax.swing.JLabel();
        passIconLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153), 8));
        jPanel2.setPreferredSize(new java.awt.Dimension(995, 732));

        jLabel_logo.setBackground(new java.awt.Color(204, 204, 204));
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/login.jpg"))); // NOI18N
        jLabel_logo.setText(" ");
        jLabel_logo.setOpaque(true);

        jLabel_title.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        jLabel_title.setText("Login");

        userNameTxt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        userNameTxt.setForeground(new java.awt.Color(153, 153, 153));
        userNameTxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                userNameTxtFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                userNameTxtFocusLost(evt);
            }
        });

        showPasswordCheckBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        showPasswordCheckBox.setText(" Show Password");
        showPasswordCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPasswordCheckBoxActionPerformed(evt);
            }
        });

        loginBtn.setBackground(new java.awt.Color(0, 204, 51));
        loginBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loginBtn.setForeground(new java.awt.Color(255, 255, 255));
        loginBtn.setText(" Login");
        loginBtn.setOpaque(true);
        loginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBtnActionPerformed(evt);
            }
        });

        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel_close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_close.setText(" x");
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        passwordTxt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passwordTxt.setForeground(new java.awt.Color(153, 153, 153));
        passwordTxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                passwordTxtFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                passwordTxtFocusLost(evt);
            }
        });

        profileIconLbl.setBackground(new java.awt.Color(255, 51, 51));
        profileIconLbl.setMinimumSize(new java.awt.Dimension(32, 32));
        profileIconLbl.setOpaque(true);

        passIconLbl.setBackground(new java.awt.Color(255, 51, 51));
        passIconLbl.setMinimumSize(new java.awt.Dimension(32, 32));
        passIconLbl.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel_title, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(195, 195, 195))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(loginBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(profileIconLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(passIconLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(26, 26, 26)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(showPasswordCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(userNameTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                                            .addComponent(passwordTxt))))
                                .addGap(0, 120, Short.MAX_VALUE))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(129, 129, 129)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel_title)
                        .addGap(64, 64, 64)
                        .addComponent(userNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(profileIconLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(passwordTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passIconLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(showPasswordCheckBox)
                .addGap(42, 42, 42)
                .addComponent(loginBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jLabel_logo)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 993, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 722, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void userNameTxtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_userNameTxtFocusGained
        if (userNameTxt.getText().equals("Username")) {
            userNameTxt.setText("");
            userNameTxt.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_userNameTxtFocusGained

    private void userNameTxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_userNameTxtFocusLost
        if (userNameTxt.getText().isEmpty()) {
            userNameTxt.setText("Username");
            userNameTxt.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_userNameTxtFocusLost

    // Show password method
    private void showPasswordCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPasswordCheckBoxActionPerformed
        if (showPasswordCheckBox.isSelected()) {
            passwordTxt.setEchoChar((char) 0);
        } else {
            passwordTxt.setEchoChar('*');
        }
    }//GEN-LAST:event_showPasswordCheckBoxActionPerformed

    // Login button click event
    private void loginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginBtnActionPerformed
        String username = userNameTxt.getText();
        String password = String.valueOf(passwordTxt.getPassword());

        // Authenticate user from db
        UserDAO userDAO = new UserDAO();
        model.User user = userDAO.authenticateUser(username, password);

        if (user != null) {
            // If credentials are valid, open dashboard
            setVisible(false);
            new Dashboard(user).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password");
        }
    }//GEN-LAST:event_loginBtnActionPerformed

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void passwordTxtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_passwordTxtFocusGained
        if (String.valueOf(passwordTxt.getPassword()).equals("Password")) {
            passwordTxt.setText("");
            passwordTxt.setEchoChar('*');
            passwordTxt.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_passwordTxtFocusGained

    private void passwordTxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_passwordTxtFocusLost
        if (String.valueOf(passwordTxt.getPassword()).isEmpty()) {
            passwordTxt.setText("Password");
            passwordTxt.setEchoChar((char) 0);
            passwordTxt.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_passwordTxtFocusLost

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_title;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton loginBtn;
    private javax.swing.JLabel passIconLbl;
    private javax.swing.JPasswordField passwordTxt;
    private javax.swing.JLabel profileIconLbl;
    private javax.swing.JCheckBox showPasswordCheckBox;
    private javax.swing.JTextField userNameTxt;
    // End of variables declaration//GEN-END:variables
}
