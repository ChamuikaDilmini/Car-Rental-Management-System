package view;

import dao.BookCarDAO;
import dao.BrandDAO;
import dao.CityAddressDAO;
import dao.LocationDAO;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import model.BookCar;

public class BookCarForm extends javax.swing.JFrame {

    private Map<String, Integer> brandMap = new HashMap<>();
    private Map<String, Integer> cityMap = new LocationDAO().getCityMap();
    private Map<String, Integer> pickupAddressMap;
    private Map<String, Integer> dropoffAddressMap;
    BookingEdit editForm;
    Dashboard dashboard;

    public BookCarForm(Dashboard dashboard) {
        initComponents();
        setTitle("Book Car");
        setLocationRelativeTo(null);
        loadCities();
        loadCarBrands();
        clearFormFields();

        this.dashboard = dashboard;
        dashboard.refreshDashboardCounts();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_brands_logo = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        jButton_Remove1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton_Edit = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        lblBrandId = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        lblModel = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        lblCarId = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        cmbCarBrand = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cmbPickupCity = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        pickupDateChooser = new com.toedter.calendar.JDateChooser();
        cmbPickupAddress = new javax.swing.JComboBox<>();
        pickupTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        jPanel6 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtCustomerName = new javax.swing.JTextField();
        lblCustomerId = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton_Edit2 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        cmbDropoffCity = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        cmbDropoffAddress = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        returnDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel20 = new javax.swing.JLabel();
        returnTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        jPanel1 = new javax.swing.JPanel();
        totalLbl = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        calculateBtn = new javax.swing.JButton();
        btnBookingCar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 5));

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Book a Car");
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel_brands_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/bookingC.png"))); // NOI18N

        jLabel_close.setText(" X");
        jLabel_close.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel_brands_logo)
                .addGap(308, 308, 308)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addComponent(jLabel_brands_logo)
                .addContainerGap(11, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton_Remove1.setText("Edit/Remove Booking");
        jButton_Remove1.setBackground(new java.awt.Color(255, 153, 0));
        jButton_Remove1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Remove1.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Remove1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Remove1ActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(0, 204, 204));

        jLabel2.setText("Brand:");
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel10.setText("Select a Car");
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));

        jLabel6.setText("ID");
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));

        jButton_Edit.setText("Select Car");
        jButton_Edit.setBackground(new java.awt.Color(102, 102, 102));
        jButton_Edit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Edit.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_EditActionPerformed(evt);
            }
        });

        jLabel12.setText("Car:");
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));

        lblBrandId.setText("1");
        lblBrandId.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblBrandId.setForeground(new java.awt.Color(255, 255, 255));

        jLabel24.setText("Price:");
        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));

        jLabel25.setText("Model:");
        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));

        lblModel.setText("###");
        lblModel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblModel.setForeground(new java.awt.Color(255, 255, 255));

        lblPrice.setText("000");
        lblPrice.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblPrice.setForeground(new java.awt.Color(255, 255, 255));

        jLabel28.setText("ID");
        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));

        lblCarId.setText("000");
        lblCarId.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblCarId.setForeground(new java.awt.Color(255, 255, 255));

        jLabel30.setText("|");
        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(204, 102, 0));

        cmbCarBrand.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCarBrand.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbCarBrand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCarBrandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(cmbCarBrand, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblModel))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(18, 18, 18)
                                .addComponent(jButton_Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel28)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblCarId)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel30)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPrice))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblBrandId)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(161, 161, 161))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6)
                    .addComponent(lblBrandId)
                    .addComponent(cmbCarBrand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_Edit)
                    .addComponent(jLabel12)
                    .addComponent(jLabel28)
                    .addComponent(lblCarId)
                    .addComponent(jLabel30)
                    .addComponent(jLabel24)
                    .addComponent(lblPrice))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(lblModel))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 204, 204));

        jLabel3.setText("City:");
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));

        cmbPickupCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbPickupCity.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbPickupCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPickupCityActionPerformed(evt);
            }
        });

        jLabel5.setText("Time:");
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));

        jLabel11.setText("Pickup Location & Date");
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));

        jLabel14.setText("Address:");
        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));

        jLabel15.setText("Date:");
        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));

        pickupDateChooser.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        pickupDateChooser.setPreferredSize(new java.awt.Dimension(94, 28));

        cmbPickupAddress.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbPickupAddress.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbPickupAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPickupAddressActionPerformed(evt);
            }
        });

        pickupTimePicker.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        pickupTimePicker.setPreferredSize(new java.awt.Dimension(90, 28));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel15)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pickupTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbPickupCity, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbPickupAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pickupDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbPickupCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cmbPickupAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(pickupDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pickupTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(0, 204, 204));

        jLabel7.setText("Customer:");
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));

        jLabel13.setText("Select Customer");
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));

        txtCustomerName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        lblCustomerId.setText("000");
        lblCustomerId.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblCustomerId.setForeground(new java.awt.Color(255, 255, 255));

        jLabel9.setText("ID");
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));

        jButton_Edit2.setText("Select Customer");
        jButton_Edit2.setBackground(new java.awt.Color(102, 102, 102));
        jButton_Edit2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_Edit2.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Edit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Edit2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(174, 174, 174)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(lblCustomerId)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton_Edit2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(84, 84, 84))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel13)
                .addGap(9, 9, 9)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_Edit2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCustomerId)
                    .addComponent(jLabel9))
                .addGap(17, 17, 17))
        );

        jPanel8.setBackground(new java.awt.Color(0, 204, 204));

        jLabel18.setText("Drop Off Location & Date");
        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));

        jLabel16.setText("City:");
        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));

        cmbDropoffCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbDropoffCity.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbDropoffCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbDropoffCityActionPerformed(evt);
            }
        });

        jLabel17.setText("Address:");
        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));

        cmbDropoffAddress.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbDropoffAddress.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        cmbDropoffAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbDropoffAddressActionPerformed(evt);
            }
        });

        jLabel19.setText("Date:");
        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));

        returnDateChooser.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        returnDateChooser.setPreferredSize(new java.awt.Dimension(94, 28));

        jLabel20.setText("Time:");
        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));

        returnTimePicker.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        returnTimePicker.setPreferredSize(new java.awt.Dimension(90, 28));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20)
                    .addComponent(jLabel16)
                    .addComponent(jLabel19)
                    .addComponent(jLabel17))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(returnTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbDropoffCity, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbDropoffAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(returnDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(cmbDropoffCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(cmbDropoffAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(returnDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(returnTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20))))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        totalLbl.setText("00000");
        totalLbl.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jLabel22.setText("Total Price:");
        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        calculateBtn.setText("Calculate");
        calculateBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        calculateBtn.setForeground(new java.awt.Color(0, 0, 51));
        calculateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(calculateBtn)
                .addGap(19, 19, 19))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(totalLbl)
                    .addComponent(calculateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 14, Short.MAX_VALUE))
        );

        btnBookingCar.setText("Book This Car");
        btnBookingCar.setBackground(new java.awt.Color(0, 51, 255));
        btnBookingCar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBookingCar.setForeground(new java.awt.Color(255, 255, 255));
        btnBookingCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookingCarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 504, Short.MAX_VALUE)
                    .addComponent(jButton_Remove1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBookingCar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(47, 47, 47)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBookingCar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton_Remove1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void calculateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateBtnActionPerformed
        try {
            if (pickupDateChooser.getDate() == null || returnDateChooser.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please select both pickup and return dates.");
                return;
            }

            if (lblPrice.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Car price is not available.");
                return;
            }

            int pricePerDay = Integer.parseInt(lblPrice.getText());
            int totalPrice = calculateTotalPrice(pricePerDay);

            totalLbl.setText(String.valueOf(totalPrice) + " LKR");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error calculating total price: " + e.getMessage());
        }
    }//GEN-LAST:event_calculateBtnActionPerformed

    private void jButton_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_EditActionPerformed
        new CarList(this, true).setVisible(true);
    }//GEN-LAST:event_jButton_EditActionPerformed

    private void jButton_Remove1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Remove1ActionPerformed
        new BookingEdit(this.dashboard).setVisible(true);
    }//GEN-LAST:event_jButton_Remove1ActionPerformed

    private void cmbPickupCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPickupCityActionPerformed
        String selectedCity = (String) cmbPickupCity.getSelectedItem();
        loadPickupAddressesByCity(selectedCity);
    }//GEN-LAST:event_cmbPickupCityActionPerformed

    private void cmbPickupAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPickupAddressActionPerformed
        String selectedCity = (String) cmbPickupAddress.getSelectedItem();
        loadPickupAddressesByCity(selectedCity);
    }//GEN-LAST:event_cmbPickupAddressActionPerformed

    private void btnBookingCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookingCarActionPerformed
        try {

            if (cmbCarBrand.getSelectedItem() == null || cmbPickupCity.getSelectedItem() == null
                    || cmbPickupAddress.getSelectedItem() == null || cmbDropoffCity.getSelectedItem() == null
                    || cmbDropoffAddress.getSelectedItem() == null || pickupDateChooser.getDate() == null
                    || returnDateChooser.getDate() == null || totalLbl.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this, "All fields are required.");
                return;
            }

            // Get selected city and address names
            String pickupCity = (String) cmbPickupCity.getSelectedItem();
            String pickupAddress = (String) cmbPickupAddress.getSelectedItem();
            String dropoffCity = (String) cmbDropoffCity.getSelectedItem();
            String dropoffAddress = (String) cmbDropoffAddress.getSelectedItem();

            // Get corresponding IDs from maps
            Integer pickupCityId = cityMap.get(pickupCity);
            Integer pickupAddressId = pickupAddressMap.get(pickupAddress);
            Integer dropoffCityId = cityMap.get(dropoffCity);
            Integer dropoffAddressId = dropoffAddressMap.get(dropoffAddress);

            if (pickupCityId == null || pickupAddressId == null || dropoffCityId == null || dropoffAddressId == null) {
                JOptionPane.showMessageDialog(this, "City or address selection is invalid.");
                return;
            }

            // Validate and get pickup and return date
            Date pickupDate = pickupDateChooser.getDate();
            Date returnDate = returnDateChooser.getDate();

            if (pickupDate == null || returnDate == null) {
                JOptionPane.showMessageDialog(this, "Please select both pickup and return dates.");
                return;
            }

            // Convert to LocalDate
            LocalDate pickupLocalDate = pickupDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate returnLocalDate = returnDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

            // Get time from TimePicker (LGoodDatePicker returns LocalTime)
            LocalTime pickupTime = pickupTimePicker.getTime();
            LocalTime returnTime = returnTimePicker.getTime();

            if (pickupTime == null || returnTime == null) {
                JOptionPane.showMessageDialog(this, "Please select both pickup and return times.");
                return;
            }

            // Combine to LocalDateTime
            LocalDateTime pickupDateTime = LocalDateTime.of(pickupLocalDate, pickupTime);
            LocalDateTime returnDateTime = LocalDateTime.of(returnLocalDate, returnTime);

            if (pickupDateTime.isAfter(returnDateTime)) {
                JOptionPane.showMessageDialog(this, "Pickup time must be before return time.");
                return;
            }

            if (lblCarId.getText().isEmpty() || lblCustomerId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select both a car and a customer.");
                return;
            }

            int carId = Integer.parseInt(lblCarId.getText());

            int customerId = Integer.parseInt(lblCustomerId.getText());

            // Calculate total price
            int pricePerDay = Integer.parseInt(lblPrice.getText());
            int totalPrice = calculateTotalPrice(pricePerDay);

            BookCar booking = new BookCar();
            booking.setCarId(carId);
            booking.setCustomerId(customerId);
            booking.setPickupCityId(pickupCityId);
            booking.setPickupAddressId(pickupAddressId);
            booking.setDropoffCityId(dropoffCityId);
            booking.setDropoffAddressId(dropoffAddressId);
            booking.setPickupDateTime(pickupDateTime);
            booking.setReturnDateTime(returnDateTime);
            booking.setTotalPrice(totalPrice);

            boolean isSaved = new BookCarDAO().saveBooking(booking);

            if (isSaved) {
                JOptionPane.showMessageDialog(this, "Booking saved successfully.");
                clearFormFields();
                dashboard.refreshDashboardCounts();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save booking.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }//GEN-LAST:event_btnBookingCarActionPerformed

    private void jButton_Edit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Edit2ActionPerformed
        new CustomerList(this).setVisible(true);
    }//GEN-LAST:event_jButton_Edit2ActionPerformed

    private void cmbDropoffCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDropoffCityActionPerformed
        String selectedCity = (String) cmbDropoffCity.getSelectedItem();
        loadDropoffAddressesByCity(selectedCity);
    }//GEN-LAST:event_cmbDropoffCityActionPerformed

    private void cmbDropoffAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDropoffAddressActionPerformed
        String selectedCity = (String) cmbDropoffAddress.getSelectedItem();
        loadDropoffAddressesByCity(selectedCity);
    }//GEN-LAST:event_cmbDropoffAddressActionPerformed

    private void cmbCarBrandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCarBrandActionPerformed
        String selectedBrandName = (String) cmbCarBrand.getSelectedItem();
        if (selectedBrandName != null && brandMap.containsKey(selectedBrandName)) {
            int selectedBrandId = brandMap.get(selectedBrandName);
            lblBrandId.setText(String.valueOf(selectedBrandId));
        }
    }//GEN-LAST:event_cmbCarBrandActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBookingCar;
    private javax.swing.JButton calculateBtn;
    public javax.swing.JComboBox<String> cmbCarBrand;
    private javax.swing.JComboBox<String> cmbDropoffAddress;
    private javax.swing.JComboBox<String> cmbDropoffCity;
    private javax.swing.JComboBox<String> cmbPickupAddress;
    private javax.swing.JComboBox<String> cmbPickupCity;
    private javax.swing.JButton jButton_Edit;
    private javax.swing.JButton jButton_Edit2;
    private javax.swing.JButton jButton_Remove1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_brands_logo;
    private javax.swing.JLabel jLabel_close;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JLabel lblBrandId;
    public javax.swing.JLabel lblCarId;
    public javax.swing.JLabel lblCustomerId;
    public javax.swing.JLabel lblModel;
    public javax.swing.JLabel lblPrice;
    private com.toedter.calendar.JDateChooser pickupDateChooser;
    private com.github.lgooddatepicker.components.TimePicker pickupTimePicker;
    private com.toedter.calendar.JDateChooser returnDateChooser;
    private com.github.lgooddatepicker.components.TimePicker returnTimePicker;
    private javax.swing.JLabel totalLbl;
    public javax.swing.JTextField txtCustomerName;
    // End of variables declaration//GEN-END:variables

    private void loadCities() {

        cityMap = new LocationDAO().getCityMap();
        cmbPickupCity.removeAllItems();
        cmbDropoffCity.removeAllItems();

        for (String city : cityMap.keySet()) {
            cmbPickupCity.addItem(city);
            cmbDropoffCity.addItem(city);
        }

    }

    private void loadPickupAddressesByCity(String city) {
        if (city == null || city.isEmpty()) {
            return;
        }

        Integer cityId = cityMap.get(city);
        if (cityId == null) {
            return;
        }

        pickupAddressMap = new CityAddressDAO().getAddressMapByCityId(cityId);
        cmbPickupAddress.removeAllItems();
        for (String address : pickupAddressMap.keySet()) {
            cmbPickupAddress.addItem(address);
        }
    }

    private void loadDropoffAddressesByCity(String city) {
        if (city == null || city.isEmpty()) {
            return;
        }

        Integer cityId = cityMap.get(city);
        if (cityId == null) {
            return;
        }

        dropoffAddressMap = new CityAddressDAO().getAddressMapByCityId(cityId);
        cmbDropoffAddress.removeAllItems();
        for (String address : dropoffAddressMap.keySet()) {
            cmbDropoffAddress.addItem(address);
        }
    }

    private void loadCarBrands() {
        brandMap = new BrandDAO().getAllBrandNameIdMap();
        cmbCarBrand.removeAllItems();
        for (String brandName : brandMap.keySet()) {
            cmbCarBrand.addItem(brandName);
        }

    }

    private int calculateTotalPrice(int pricePerDay) {
        Date pickupDate = pickupDateChooser.getDate();
        Date returnDate = returnDateChooser.getDate();
        LocalTime pickupTime = pickupTimePicker.getTime();
        LocalTime returnTime = returnTimePicker.getTime();

        if (pickupDate == null || returnDate == null || pickupTime == null || returnTime == null) {
            throw new IllegalArgumentException("Pickup and return date/time must be selected.");
        }

        LocalDateTime pickupDateTime = LocalDateTime.of(
                pickupDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
                pickupTime
        );

        LocalDateTime returnDateTime = LocalDateTime.of(
                returnDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
                returnTime
        );

        if (pickupDateTime.isAfter(returnDateTime)) {
            throw new IllegalArgumentException("Pickup date/time must be before return date/time.");
        }

        long totalHours = ChronoUnit.HOURS.between(pickupDateTime, returnDateTime);

        // Round up to the next full day if there's a partial day
        long totalDays = (long) Math.ceil(totalHours / 24.0);

        return (int) (totalDays * pricePerDay);
    }

    private void clearFormFields() {
        // ComboBoxes
        cmbCarBrand.setSelectedIndex(-1);
        lblBrandId.setText("");

        cmbPickupCity.setSelectedIndex(-1);
        cmbPickupAddress.removeAllItems();

        cmbDropoffCity.setSelectedIndex(-1);
        cmbDropoffAddress.removeAllItems();

        // DatePickers
        pickupDateChooser.setDate(null);
        returnDateChooser.setDate(null);

        // TimePickers
        pickupTimePicker.setTime(null);
        returnTimePicker.setTime(null);

        // Labels
        lblCarId.setText("");
        lblCustomerId.setText("");
        lblModel.setText("");
        lblPrice.setText("");
        totalLbl.setText("");

        // Text fields
        txtCustomerName.setText("");
    }
}
